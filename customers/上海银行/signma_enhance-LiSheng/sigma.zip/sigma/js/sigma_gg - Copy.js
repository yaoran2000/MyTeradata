function preloadImages() {
	var preloads = [
'select2/select2.png',
'select2/select2-spinner.gif',
'select2/select2x2.png',
'img/b_pause.png',
'img/b_pause_over.png',
'img/b_play.png',
'img/b_play_over.png',
'img/close24x24.png',
'img/gephi.png',
'img/gexf.png',
'img/popup.png',
'img/spinner.gif'
];
	$(preloads).each(function(){
		$('<img/>')[0].src = this;
	});
}

//added by Jackie ---begin
function dl_visible_nodes(nodelist) {
  	var blob = new Blob([nodelist], {type: "text/plain;charset=utf-8"});
  	var fileName = prompt('What is file name?', 'visiblenodes');
		saveAs(blob, fileName + ".txt");
}
//added by Jackie ---end


function init(config, attr_key, attr_value) {
	// Set sigma container height correctly
	windowHeight = $(window).height();
	$("#sigma-example-parent").css("height", windowHeight-75);
	$(window).bind('resize',function(){
		windowHeight = $(window).height();
		$("#sigma-example-parent").css("height", windowHeight-75);
		resizeProperties();
	});

	// Set html and header title
	$('.pagetitle').text(config.text.title);

	// Set download graph link
	$('#download_graph').attr('href',config.data);

	// Tooltips for generated divs
	// Note: tooltips for static divs are defined in the div itself
	var tooltipArray = {
			// Graph Properties
			"Directed": "Indicates if the graph is directed (true) or undirected (false). Directed graphs have edges pointing (using arrows) from one node to another.",
			"Node Count": "Total number of nodes in the graph.",
			"Edge Count": "Total number of edges in the graph. Directed graphs have a maximum of two edges between a pair of nodes. Undirected graphs have a maximum of one edge between a pair of nodes. ",
			"Communities": "Total number of communities in the graph. Communities are groups of nodes that have something in common or are closely related to each other. The groups are assigned using a modularity algorithm which is a type of unsupervised clustering. Each community has its own color. Note that the community count may be different if you re-generate the same graph since the algorithm is based on a comparison to a random distribution of links between all nodes.",
			"Max Node": "The largest node size (value) of all nodes in the graph. You can use the Node Filter to find the largest nodes.",
			"Min Node": "The smallest node size (value) of all nodes in the graph. You can use the Node Filter to find the smallest nodes.",
			"Max Edge": "The largest edge size (value) of all edges in the graph. You can use the Edge Visibility Filter to find the largest edges.",
			"Min Edge": "The smallest edge size (value) of all edges in the graph. You can use the Edge Visibility Filter to find the smallest edges.",			
			"Max Degree": "For undirected graphs, degree is a count of how many nodes to which this node links. For directed graphs, degree is in-degree plus out-degree. This is the maximum value of degree for all nodes.",
			"Min Degree": "For undirected graphs, degree is a count of how many nodes to which this node links. For directed graphs, degree is in-degree plus out-degree. This is the minimum value of degree for all nodes.",
			"Max In-Degree": "In directed graphs, in-degree is a count of how many nodes point to this node. This is the maximum value of in-degree for all nodes.",
			"Min In-Degree": "In directed graphs, in-degree is a count of how many nodes point to this node. This is the minimum value of in-degree for all nodes.",
			"Max Out-Degree": "In directed graphs, out-degree is a count of how many nodes to which this node points. This is the maximum value of out-degree for all nodes.",
			"Min Out-Degree": "In directed graphs, out-degree is a count of how many nodes to which this node points. This is the minimum value of out-degree for all nodes.",
			"Avg Degree": "The average total degree of all nodes. For undirected graphs, degree is a count of how many nodes to which this node links. For directed graphs, degree is in-degree plus out-degree.",
			"Max Betweenness": "The highest betweenness centrality value of all nodes. Higher values indicate nodes that might be gateways or bridges between clusters. Betweenness is equal to the number of times a node appears on the shortest path between two other nodes. You can use the Betweenness Filter to find the nodes with the highest values.",
			"Min Betweenness": "The smallest betweenness centrality value of all nodes. Smaller values indicate nodes that tend to appear on the outside of a graph and do not link clusters together. Betweenness is equal to the number of times a node appears on the shortest path between two other nodes. You can use the Betweenness Filter to find the nodes with the lowest values.",
			"Max PageRank": "The highest PageRank value of all nodes. The PageRank value is weighted (based on edge thickness) and directional (for directed graphs). PageRank measures the relative importance of a node in a graph. Note that the largest node isn't always the node with the highest PageRank.",
			"Min PageRank": "The smallest PageRank value of all nodes. The PageRank value is weighted (based on edge thickness) and directional (for directed graphs). PageRank measures the relative importance of a node in a graph. Note that the smallest node isn't always the node with the smallest PageRank.",
			"Avg Path Length": "The average number of steps along the shortest paths for all possible pairs of graph nodes. It is a measure of the efficiency of information or mass transport on a network. (source: Wikipedia)",
			"Diameter": "The longest shortest path between any two nodes in the graph. (source: Wikipedia)",

			"Node Value": "The value of a node, which corresponds to its size, is a measure of how popular or common the node is. For graphs showing collaborative filter results, the node value is how many times the item was purchased (or browsed, searched, viewed, etc, depending which metric was used). For graphs showing paths, the node value is how many times that page was landed on.",
			"Modularity Class": "The ID of the community (group of nodes) this node belongs to. Each community has a unique color and a unique number assigned to it. The number identifies the community. There is no significance to higher or lower numbers.",
			"Eccentricity": "How far this node is from the node most distant from it in the graph. The maximum eccentricity of all nodes equals the diameter of the graph.",
			"Closeness": " Closeness centrality is a measure of how long it will take to spread information from this node to all other nodes sequentially. The more central a node is the lower its total distance (and, thus, the lower its closeness value) to all other nodes.",
			"Betweenness": "Betweenness centrality is equal to the number of times a node appears on the shortest path between two other nodes. Higher values indicate nodes that might be gateways or bridges between clusters.",
			"PageRank": "PageRank measures the relative importance of a node in a graph. Note that the largest node isn't always the node with the highest PageRank. The PageRank value is weighted (based on edge thickness) and directional (for directed graphs).",
			"In-Degree": "In directed graphs, in-degree is a count of how many nodes point to this node.",
			"Out-Degree": "In directed graphs, out-degree is a count of how many nodes to which this node points.",
			"Degree": "In undirected graphs, degree is a count of how many nodes to which this node links.",
			"Edge Value": "The value of an edge, which corresponds to its size, is a measure of how strongly connected two nodes are. For graphs showing collaborative filter results, the edge value is specified by the user generating the graph and may be the cfilter score or confidence (or some other affinity measurement), for example. For graphs showing paths, the edge value is the number of times a pathway between two nodes was traversed.",
			"Count Both": "A collaborative filter edge attribute. Indicates the number of times this item and the item it is linked to are purchased together (or browsed, searched, viewed, etc, depending which metric was used).",
			"Score": "A collaborative filter edge attribute. Score is an undirected affinity between two nodes (i.e. the scores for A->B and B->A are the same, regardless if the graph is directed).",
			"Support": "A collaborative filter edge attribute. An undirected measure of how popular a basket pair is amongst all baskets. The support values for A->B and B->A are the same.",
			"Confidence": "A collaborative filter edge attribute. A directed measure of how often item A is bought when item B is bought. E.g. if A->B has a confidence of 0.85, when A is bought, B is bought 85% of the time. Since it is a directed measure, the confidence of A->B and B->A are typically different.",
			"Lift": "A collaborative filter edge attribute. An undirected measure. Values > 1 are generally considered good and indicate the item will sell (or appear) more often if the other item exists (whereas if the other item did not exist, this item would sell less).",
			"Z-Score": "A collaborative filter edge attribute. An undirected measure indicating how many standard deviations the count-both value is above or below the mean. E.g. a zscore of 1 would put the pair of nodes (based on count-both) in the top 84.1 percentile. A zscore of 2 would put it in the top 97.7 percentile."
	};

	// resize panes for node and graph properties
	function resizeProperties() {
		if ( $('#prop_connNodes').length )
			$('#prop_connNodes').css('height', windowHeight - $('#prop_connNodes').offset().top - 31 );
		if ( $('#prop_inboundNodes').length )  {
			$('#prop_inboundNodes').css('height', (windowHeight - $('#prop_inboundNodes').offset().top)/2 - 57 );
			if ( $('#prop_outboundNodes').length )
				$('#prop_outboundNodes').css('height', (windowHeight - $('#prop_inboundNodes').offset().top)/2 - 57 );
		}
		if ( $('#graphproperties').length )
			$('#graphproperties').css('max-height', windowHeight - $('#graphproperties').offset().top - 31 );
	}

	// tab configuration
	$(function() {
		$('#tabs').tabs();
		$('#tabs').tabs().removeClass('ui-widget');
		$('#tabs ul .ui-widget-header').tabs().attr('background','');
		$('#tabs').tabs({
			show: function(event, ui){
				resizeProperties(); // resize property panes when changing tabs
			}
		});
	});

	var minNodeSize = config.sigma.graphProperties.minNodeSize;
	var maxNodeSize = config.sigma.graphProperties.maxNodeSize;
	var minEdgeSize = config.sigma.graphProperties.minEdgeSize;
	var maxEdgeSize = config.sigma.graphProperties.maxEdgeSize;
	var labelThreshold = (maxNodeSize - (maxNodeSize-minNodeSize)*0.2);
	// Instantiate sigma.js and customize rendering
	var sigInst = sigma.init(document.getElementById('sigma-example'))
	.drawingProperties(config.sigma.drawingProperties)
	.graphProperties(config.sigma.graphProperties)
	.mouseProperties(config.sigma.mouseProperties)
	.drawingProperties({
		labelThreshold: labelThreshold
	});
	
	// Color themes
	function setTheme(theme) {
		if (theme == 'dark') {
			sigInst.drawingProperties({
				defaultLabelColor: '#fff',
				defaultLabelHoverColor: '#000',
				defaultHoverLabelBGColor: '#fff',
				labelHoverShadowColor: '#000',
				edgeLabelColor: '#fff',
				nodeBorderColor: 'custom',
				defaultNodeBorderColor: '#eee',
				defaultEdgeColor: '#555'
			}).draw();
			$('#sigma-example-parent').css('background', '#111');
		} else if (theme == 'light') {
			sigInst.drawingProperties({
				defaultLabelColor: '#111',
				defaultLabelHoverColor: '#fff',
				defaultHoverLabelBGColor: '#111',
				labelHoverShadowColor: '#fff',
				edgeLabelColor: '#111',
				nodeBorderColor: 'custom',
				defaultNodeBorderColor: '#111',
				defaultEdgeColor: '#bbb'
			}).draw();
			$('#sigma-example-parent').css('background', '#fff');
		} else if (theme == 'lightgray') {
			sigInst.drawingProperties({
				defaultLabelColor: '#000', // node label text color
				defaultLabelHoverColor: '#fff', // node label text color on hover
				defaultHoverLabelBGColor: '#002147', // node label highlight color on hover
				labelHoverShadowColor: '#fff', // perimeter around highlight color
				edgeLabelColor: '#000', // edge label text color
				nodeBorderColor: 'custom',
				defaultNodeBorderColor: '#000',
				defaultEdgeColor: '#AFAFAF'
			}).draw();
			$('#sigma-example-parent').css('background', '#EFEFEF');
		} else if (theme == 'gray') {
			sigInst.drawingProperties({
				defaultLabelColor: '#C3C3C3',
				defaultLabelHoverColor: '#404040',
				defaultHoverLabelBGColor: '#C3C3C3',
				labelHoverShadowColor: '#8A8A8A',
				edgeLabelColor: '#C3C3C3',
				nodeBorderColor: 'custom',
				defaultNodeBorderColor: '#C3C3C3',
				defaultEdgeColor: '#808080'
			}).draw();
			$('#sigma-example-parent').css('background', '#404040');
		}
	}

	var node = new Array();
	var attr_nodes = new Array();
	var skip = false;
	
	// Parse a GEXF encoded file to fill the graph
	// (requires "sigma.parseGexf.js" to be included)
	sigInst.parseGexf(config.data, attr_key, attr_value, attr_nodes);
	sigInst.sortEdges("-label"); // sort edges so largest edge value appears first in properties

	// Round a number to specified significant figures
	Math.sig = function (num, sig) {
		if (num == 0)
			return 0;
		if (Math.round(num) == num)
			return num;
		if (num < 10)
			return num.toFixed(sig);
		var digits = Math.round((-Math.log(Math.abs(num)) / Math.LN10) + (sig || 2)); //round to significant digits (sig)
		if (digits < 0)
			digits = 0;
		return num.toFixed(digits);
	};
	
	// escape a DIV ID so it complies with HTML spec (e.g. no spaces)
	function escapeID(str) {
		return str.replace(/([;&,\.\+\*\~':"\!\^#$%@\[\]\(\)=>\|])/g, '\\$1').replace(/ /g, '_');
	}

	///////////////////////////
	// setup graph properties pane
	///////////////////////////

	var modalID = 0;
	var proprowToggle = 0;
	$.each(config.graphProperties, function(key, value) {
		if (value.propValue != null)
			proprow("graphproperties", value.propLabel, formatVal(value.propValue, value.propDataType), "graphproperties_" + key, value.propDataType);
	});

	///////////////////////////
	// setup properties pane
	///////////////////////////
    
	function formatVal (value, datatype) {
		if (datatype == 'float' || datatype == 'double') { return (Math.sig(Number(value),6)); }
		else if (datatype == 'long') { return (Number(value).toPrecision(4)); }
		else if (datatype == 'string') { return value.replace(/&#10;/g,"<br>"); }
		else { return value; }
	}

	function proprow (divid, propname, propvalue, propvalueid, datatype) {
		propvalueid = escapeID(propvalueid);
		html = '';
		if (proprowToggle == 0) {
			html += '<div class="proprow">';
			proprowToggle++;
		} else {
			html += '<div class="proprow proprowgray">';
			proprowToggle--;
		}
		// get tooltip if available
		var title = "";
		if (typeof tooltipArray[propname] === 'undefined') {
			title = propname;
		} else {
			title = tooltipArray[propname];
		}

		// long strings need special formatting, e.g. put on their own row with expander
		if (datatype == 'string' && propvalue.length > 24)
			isExpander = true;
		else
			isExpander = false;
		if (isExpander) {
			modalLink = '<a href="#" data-animation="none" data-reveal-id="modalPopup_' + ++modalID + '"><img title="View full text" class="titletip left-image" src="img/popup.png"></a>';
			expanderPropvalue = '<div class="expander">' + propvalue + '</div>';
			html += '   <div class="helptip" title="' + title + '">' + propname + '</div>';
			html += '   <div id="' + propvalueid + '">' + modalLink + expanderPropvalue + '</div>';
		}
		else {
			html += '   <div class="propname helptip" title="' + title + '">' + propname + '</div>';
			html += '   <div id="' + propvalueid + '" class="propvalue">' + propvalue + '</div>';
		}
		html += '</div>';
		$('#' + divid).append(html);

		if (isExpander) {
			// Create a div for the modal popup if it doesn't already exist.
			// Once we know it exists, append the actual text (propvalue) to the div.
			modalDivID = "modal_" + divid;
			if ($('#' + modalDivID).length === 0) {
				$('#modalParent').append('   <div id="' + modalDivID + '"></div>');
			}
			$('#' + modalDivID).append('   <div id="modalPopup_' + modalID + '" class="reveal-modal">' + propvalue + ' <a class="close-reveal-modal">&#215;</a></div>');


			$('div.expander').expander({
				afterExpand: function() {
					$(this).find('.details').css({display: 'inline'});
					resizeProperties();
				},
				afterCollapse: function() {
					resizeProperties();
				},
				slicePoint: 50,
				widow: 2,
				expandSpeed: 0,
				collapseSpeed: 0,
				expandText: '<span class="expander-link">[more]</span>',
				expandPrefix: ' ... ',
				userCollapseText: '<span class="expander-link">[less]</span>'
			});
		}

	}

	function propheaderrow (divid, propnode) {
		var headerRowDivID = divid + '_' + propnode.id;
		html = '<div class="titletip propheaderrow" id="' + headerRowDivID + '">' + propnode.label + '</div>';
		$('#' + divid).append(html);
		$('#' + headerRowDivID)
		.click(function() { showActiveNode(propnode.id); })
		.hover(function() { sigInst.refresh(); highlightNode(propnode.id); })
		.css('cursor','pointer')
		.attr('title','View node properties');
	}

	function propspacerrow (divid) {
		html = '<div class="propspacerrow"></div>';
		$(divid).append(html);
	}

	function showNodeProps(divid, thisNode) {
		proprowToggle = 0;
		for (var i=0 ; i < thisNode['attr']['attributes'].length ; i++) {
			nodeAttrName = thisNode['attr']['attributes'][i].attr;
			nodeAttrTitle = sigInst.getNodeAttribute(thisNode['attr']['attributes'][i].attr).title;
			nodeAttrValue = thisNode['attr']['attributes'][i].val;
			nodeAttrType = sigInst.getNodeAttribute(thisNode['attr']['attributes'][i].attr).type;
			if (nodeAttrName == 'nodeValue')
				nodeAttrTitle = 'Node Value';
			else if (nodeAttrName == 'closnesscentrality')
				nodeAttrTitle = 'Closeness';
			else if (nodeAttrName == 'betweenesscentrality')
				nodeAttrTitle = 'Betweenness';
			proprow(divid, nodeAttrTitle, formatVal(nodeAttrValue, nodeAttrType), divid + '_' + nodeAttrName, nodeAttrType);
		}
	}

	// Connected/in/outbound node property panels, depending on if graph is (un)directed
	if (graphDirection == 'undirected') {
		$('#tabs-properties').append('<div class="label" style="position: relative; top: 45px; width: 258px;">Connected Nodes</div>');
		$('#tabs-properties').append('<div id="prop_connNodes" class="divborder" style="overflow:auto; position: relative; top: 50px; width: 240px;"></div>');
	} else {
		$('#tabs-properties').append('<div class="label" style="position: relative; top: 45px; width: 258px;">Inbound Nodes</div>');
		$('#tabs-properties').append('<div id="prop_inboundNodes" class="divborder" style="overflow:auto; position: relative; top: 50px; width: 240px;"></div>');
		$('#tabs-properties').append('<div class="label" style="position: relative; top: 80px; width: 258px;">Outbound Nodes</div>');
		$('#tabs-properties').append('<div id="prop_outboundNodes" class="divborder" style="overflow:auto; position: relative; top: 85px; width: 240px;"></div>');
	}
	
	
	
	// undo show neighbor mode and restore graph back to original appearance + filters applied
	function restoreGraph() {
		node = [];
		sigInst.iterEdges(function(e){
			showHideEdge(e);
		}).iterNodes(function(n){
			showHideNode(n);
		}).draw();
		
		if(attr_nodes.length > 0){
			for(var i=0; i<attr_nodes.length; i++){
				showActiveNode(attr_nodes[i]);
				skip = true;
			}
			for(var i=0; i<attr_nodes.length; i++){
				highlightNode(attr_nodes[i]);
			}
			skip = false;
		}
	}

	// Display button that a user can click to exit neighbor mode
	function showRestoreGraphButton() {
		$('#view_graph').html('').append('<div id="view_graph_button"></div>');
		$('#view_graph_button')
		.html('Exit Neighbor View')
		.addClass('left-close')
		.click(function() {
			restoreGraph();
			$(this).remove();
		});	
	}

	
	// Input: a single node object
	// Action: The node and its closest neighbors are shown. The property panes are updated.
	function showActiveNode(nodeID) {
		node.push(nodeID);
		showRestoreGraphButton(); 
		// populate properties pane for highlighted node 
		var thisNode = sigInst.getNode(nodeID);
		if(!skip){
			$('#prop_node').html(''); // clear previous properties
			$('#modal_prop_node').html(''); // clear modal popup
			propheaderrow('prop_node', thisNode);
			showNodeProps('prop_node', thisNode);
			
			if (graphDirection == 'undirected') {
				if (typeof sigInst.getNodeAttributes().degree === 'undefined')
					proprow('prop_node', 'Degree', thisNode.degree, 'prop_degree', 'integer');
				$('#prop_connNodes').html(''); // clear previous properties
				$('#modal_prop_connNodes').html(''); // clear modal popup
			} else {
				// Degree check is provided for backwards compatibility.
				// Newer versions of graphgen have degree inside the GEXF so they don't need to use sigma degree properties.
				if (typeof sigInst.getNodeAttributes().indegree === 'undefined')
					proprow('prop_node', 'In-Degree', thisNode.inDegree, 'prop_indegree', 'integer');
				if (typeof sigInst.getNodeAttributes().outdegree === 'undefined')
					proprow('prop_node', 'Out-Degree', thisNode.outDegree, 'prop_outdegree', 'integer');
				$('#prop_inboundNodes').html('');
				$('#prop_outboundNodes').html('');
				$('#modal_prop_inboundNodes').html(''); // clear modal popup
				$('#modal_prop_outboundNodes').html(''); // clear modal popup
			}
        }
		var neighbors = {};
		var firstConnNode = true;
		var firstInNode = true;
		var firstOutNode = true;
        
		sigInst.iterEdges(function(e){ 
			// Check if edge contains the active node
			
			if(node.indexOf(e.source)>=0 || node.indexOf(e.target)>=0){
				neighbors[e.source] = 1;
				neighbors[e.target] = 1;
			if(!skip){
				if (graphDirection == 'undirected') {
					if (firstConnNode)
						firstConnNode = false;
					else
						propspacerrow('#prop_connNodes');
					if(node[node.length-1] === e.target){
						propheaderrow('prop_connNodes', sigInst.getNode(e.source));
						showNodeProps('prop_connNodes', sigInst.getNode(e.source));
						proprow('prop_connNodes', 'Edge Value', formatVal(e.label, 'float' ), 'prop_connnode_edgevalue', 'float');
						for (var i=0 ; i < e['attr']['attributes'].length ; i++) {
							proprow('prop_connNodes',
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).title,
									formatVal(e['attr']['attributes'][i].val, sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type ),
									'prop_connnode_' + e['attr']['attributes'][i].attr,
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type);
						}
					}
					else if(node[node.length-1] === e.source){
						if(node[node.length-1] !== e.target){ //avoid showing self-referring node more than once
							propheaderrow('prop_connNodes', sigInst.getNode(e.target));
							showNodeProps('prop_connNodes', sigInst.getNode(e.target));
							proprow('prop_connNodes', 'Edge Value', formatVal(e.label, 'float' ), 'prop_connnode_edgevalue', 'float');
							for (var i=0 ; i < e['attr']['attributes'].length ; i++) {
								proprow('prop_connNodes', 
										sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).title, 
										formatVal(e['attr']['attributes'][i].val, sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type ), 
										'prop_connnode_' + e['attr']['attributes'][i].attr,
										sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type);
							}
						}
					}
				} else {
					if(node[node.length-1] === e.target) { // check if edge is indegree to highlighted node
						if (firstInNode)
							firstInNode = false;
						else
							propspacerrow('#prop_inboundNodes');
						propheaderrow('prop_inboundNodes', sigInst.getNode(e.source));
						showNodeProps('prop_inboundNodes', sigInst.getNode(e.source));
						proprow('prop_inboundNodes', 'Edge Value', formatVal(e.label, 'float'), 'prop_inbound_edgevalue', 'float');
						for (var i=0 ; i < e['attr']['attributes'].length ; i++) {
							proprow('prop_inboundNodes', 
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).title,
									formatVal(e['attr']['attributes'][i].val, sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type ), 
									'prop_inbound_' + e['attr']['attributes'][i].attr,
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type);
						}
					}
					if(node[node.length-1] === e.source) { // we don't use an "else" because of self-referring nodes
						if (firstOutNode)
							firstOutNode = false;
						else
							propspacerrow('#prop_outboundNodes');
						propheaderrow('prop_outboundNodes', sigInst.getNode(e.target));
						showNodeProps('prop_outboundNodes', sigInst.getNode(e.target));
						proprow('prop_outboundNodes', 'Edge Value', formatVal(e.label, 'float'), 'prop_outbound_edgevalue', 'float');
						for (var i=0 ; i < e['attr']['attributes'].length ; i++) {
							proprow('prop_outboundNodes', 
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).title,
									formatVal(e['attr']['attributes'][i].val, sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type ),
									'prop_outbound_' + e['attr']['attributes'][i].attr,
									sigInst.getEdgeAttribute(e['attr']['attributes'][i].attr).type);
						}
					}
				}
			}
			}
		}).iterNodes(function(n){
			if(!neighbors[n.id]){
				n.hidden = 1;
			}else{
				n.hidden = 0;
			}
		}).draw();
		$("#tabs").tabs("select", "#tabs-properties"); // switch tabs to show properties pane
		highlightNode(nodeID); // highlight the node so we can see it
		resizeProperties();
	}
    
	// Clear highlight node when mouseout
	sigInst.bind('outnodes',function(event){
		sigInst.refresh();
	});
    
	// Show neighbors
	sigInst.bind('upnodes',function(event){
		showActiveNode(event.content[0]);
	});
	
	// Draw the graph :
	sigma.instances[1].iterEdges(function(e){
		e.size=e.weight;
	}).draw();

	
	// forceatlas2
	var timer = new Timer();
	var isRunning = false;
	sigInst.createForceAtlas2();
	function stopLayout() {
		isRunning = false;
		sigInst.stopForceAtlas2();
		$('#layoutStartStop').attr('src',"img/b_play.png");
		$('#layoutStatus').html("Layout Stopped");
		timer.cancel();
	}
	function startLayout() {
		if(isRunning){
			timer.cancel();
		} else {
			isRunning = true;
			sigInst.startForceAtlas2();
			$('#layoutStartStop').attr('src',"img/b_pause.png");
			$('#layoutStatus').html("Layout Running");
		}
		timer.start();
	}
	function toggleLayoutRunning() {
		if(isRunning){
			stopLayout();
		}else{
			startLayout();
		}
	}

	// Count down timer for layout
	function Timer() {
		var timerId;

		this.cancel = function() {
			clearTimeout(timerId);
			$("#countdown").text('');
		};

		this.start = function() {
			var seconds = 10;
			timerId = setTimeout(updateCountdown, 1000);
			$("#countdown").text(seconds);

			function updateCountdown() {
				seconds--;
				if (seconds > 0 && isRunning) {
					$("#countdown").text(seconds);
					timerId = setTimeout(updateCountdown, 1000);
				} else {
					$("#countdown").text('');
					stopLayout();
				}
			}
		};
	}

	$('#layoutStartStop').click(function() {
		toggleLayoutRunning();
	}).css('cursor','pointer');
	$('#layoutStartStop').mouseover(function() {
		if(isRunning){
			$(this).attr('src',"img/b_pause_over.png");
		}else{
			$(this).attr('src',"img/b_play_over.png");
		}
	});
	$('#layoutStartStop').mouseout(function() {
		if(isRunning){
			$(this).attr('src',"img/b_pause.png");
		}else{
			$(this).attr('src',"img/b_play.png");
		}
	});

	$('#rescale-graph').click(function() {
		sigInst.position(0,0,1).draw();
	});

	$(".regularSelect2").select2({
		minimumResultsForSearch: -1
	});
	
	$('input[name=edgeLabels]').change(function(){
		sigInst.drawingProperties({  showEdgeLabels: $(this).prop('checked') }).draw();
	});
	$('input[name=edgeLabels]:checked').change();
	
	$('input[name=selfnodes]').change(function(){
		sigInst.drawingProperties({  showSelfNodes: $(this).prop('checked') }).draw();
	});
	$('input[name=selfnodes]:checked').change();
	
	$('input[name=orphannodes]').change(function(){
		sigInst.drawingProperties({  showOrphanNodes: $(this).prop('checked') }).draw();
	});
	$('input[name=orphannodes]:checked').change();
	
	$('input[name=nodeborder]').change(function(){
		if ($(this).prop('checked')) sigInst.drawingProperties({  borderSize: 0.9 }).draw();
		else sigInst.drawingProperties({  borderSize: 0 }).draw();
	});
	$('input[name=nodeborder]:checked').change();
  
 //added by Jackie ---begin
  $("input[name=saveas]").click( function()
  		{
    		dl_visible_nodes(get_visible_nodes());
    	}
   )
//added by Jackie ---end

	// edge color
	var edge_color, previous_edge_color;
	$('#edgeColorSelector')
	.change(function(){
		edge_color = $(this).val();
		previous_edge_color = edge_color;
	})
	.on('select2-close', function(e) {
		edge_color = previous_edge_color;
	})
	.on('select2-highlight', function(e) {
		edge_color = e.val;
	})
	.on('change select2-highlight select2-close', function(e) {
		sigInst.drawingProperties({ edgeColor: edge_color }).draw();
	});		
	$('#edgeColorSelector').change();

	// theme color
	var theme, previous_theme;
	$("#themeSelector")
	.change(function(){
		theme = $(this).val();
		previous_theme = theme;
	})
	.on('select2-close', function(e) {
		theme = previous_theme;
	})
	.on('select2-highlight', function(e) {
		theme = e.val;
	})
	.on('change select2-highlight select2-close', function(e) {
		setTheme( theme );
	});
	$('#themeSelector').change();

	// edge type
	var edgeType, previous_edgeType;
	$("#edgeTypeSelector")
	.change(function(){
		edgeType = $(this).val();
		previous_edgeType = edgeType;
	})
	.on('select2-close', function(e) {
		edgeType = previous_edgeType;
	})
	.on('select2-highlight', function(e) {
		edgeType = e.val;
	})
	.on('change select2-highlight select2-close', function(e) {
		sigInst.drawingProperties({  defaultEdgeType: edgeType }).draw();
	});
	$('#edgeTypeSelector').change();
	
	//node slider
	$( "#slider_nodes" ).slider({
		min: 0.2,
		max: 3.0,
		value: 1.0,
		step: 0.2,
		animate: true,
		slide: function(event,ui) {
			var sliderThreshold = $("#slider_labelthreshold").slider('value');
			sigInst.graphProperties({  minNodeSize: ui.value*minNodeSize, maxNodeSize: ui.value*maxNodeSize}).drawingProperties({labelThreshold: ((maxNodeSize*ui.value) - ((maxNodeSize*ui.value)-(minNodeSize*ui.value))*sliderThreshold) }).draw();
		}
	});

	// edge slider
	$( "#slider_edges" ).slider({
		min: 0.1,
		max: 3.6,
		value: 1.0,
		step: 0.1,
		animate: true,
		slide: function(event,ui) {
			sigInst.graphProperties({  minEdgeSize: ui.value*minEdgeSize, maxEdgeSize: ui.value*maxEdgeSize}).draw();
		}
	});

	var slider_filternodes = new Array();
    var slider_filteredges = new Array();
	var slider_betweenness = new Array();
	var slider_pagerank = new Array();
	var slider_degree = new Array();
	var slider_indegree = new Array();
	var slider_outdegree = new Array();
	
	var communities_filter = new Array();
	// Show or hide a node based on slider filters.
	// Function sets node's hidden flag on/off based on sliders.
	// Input: a single node
	// Output: function doesn't output anything, but does set that node's hidden field
	function showHideNode(n) {
		var betweenesscentrality = sigInst.getNodeAttr(n,'betweenesscentrality');
		var pagerank = sigInst.getNodeAttr(n,'pageranks');
		var modClass = sigInst.getNodeAttr(n,'modularity_class');
		var degree = sigInst.getNodeAttr(n,'degree');
		var indegree = sigInst.getNodeAttr(n,'indegree');
		var outdegree = sigInst.getNodeAttr(n,'outdegree');
		
		if (
				n.size <= Math.exp(slider_filternodes[1]).toFixed(4) &&
				n.size >= Math.exp(slider_filternodes[0]).toFixed(4) &&
				
				(
						typeof betweenesscentrality === 'undefined' ||
						slider_betweenness.length == 0 ||
						(
								betweenesscentrality <= slider_betweenness[1] &&
								betweenesscentrality >= slider_betweenness[0]
						)				
				) &&

				(
						typeof pagerank === 'undefined' ||
						slider_pagerank.length == 0 ||
						(
								pagerank <= slider_pagerank[1] &&
								pagerank >= slider_pagerank[0]
						)				
				) &&

				(
						typeof degree === 'undefined' ||
						slider_degree.length == 0 ||
						(
								degree <= slider_degree[1] &&
								degree >= slider_degree[0]
						)				
				) &&

				(
						typeof indegree === 'undefined' ||
						slider_indegree.length == 0 ||
						(
								indegree <= slider_indegree[1] &&
								indegree >= slider_indegree[0]
						)				
				) &&
				
				(
						typeof outdegree === 'undefined' || // check if node has this attribute
						slider_outdegree.length == 0 || // check if slider exists for this attribute
						(
								outdegree <= slider_outdegree[1] &&
								outdegree >= slider_outdegree[0]
						)				
				) &&
				
				(
						communities_filter.length == 0 ||
						jQuery.inArray(modClass, communities_filter) > -1
				)
		) {
			n.hidden=0;
		} else {
			n.hidden=1;
		}
	}

	function showHideEdge(e) {
		
		if (
				e.size <= Math.exp(slider_filteredges[1]).toFixed(4) &&
				e.size >= Math.exp(slider_filteredges[0]).toFixed(4)
		) {
			e.hidden=0;
		} else {
			e.hidden=1;
		}
	}


    function get_visible_nodes()
    {	
    		var visible_nodes="";
    		sigInst.iterNodes(function(a){
    				if(! a.hidden )
    				{
    						visible_nodes = visible_nodes + a.label + "\r\n";
    				}
    			}
    		)
    		return visible_nodes;
    }
    
    
	//filter edge slider
	$( "#slider_filteredges" ).slider({
		min: Math.log(minEdgeSize),
		max: Math.log(maxEdgeSize),
		values: [ Math.log(minEdgeSize), Math.log(maxEdgeSize) ],
		step: (Math.log(maxEdgeSize)-Math.log(minEdgeSize))/25,
		animate: true,
		create: function(event,ui) {
			slider_filteredges[0] = Math.log(minEdgeSize);
			slider_filteredges[1] = Math.log(maxEdgeSize);
		},
		slide: function(event,ui) {
			if (ui.values[ 0 ] >= ui.values[ 1 ]) {
				return false;
			} else {
				slider_filteredges[0] = ui.values[ 0 ];
				slider_filteredges[1] = ui.values[ 1 ];
				sigma.instances[1].iterEdges(function(e){
					showHideEdge(e);
				}).draw();
			}
		}
	});

	//filter node slider
	$( "#slider_filternodes" ).slider({
		min: Math.log(minNodeSize),
		max: Math.log(maxNodeSize),
		values: [ Math.log(minNodeSize), Math.log(maxNodeSize) ],
		step: (Math.log(maxNodeSize)-Math.log(minNodeSize))/25,
		animate: true,
		create: function(event,ui) {
			slider_filternodes[0] = Math.log(minNodeSize);
			slider_filternodes[1] = Math.log(maxNodeSize);
		},
		slide: function(event,ui) {
			if (ui.values[ 0 ] >= ui.values[ 1 ]) {
				return false;
			} else {
				slider_filternodes[0] = ui.values[ 0 ];
				slider_filternodes[1] = ui.values[ 1 ];
				sigma.instances[1].iterNodes(function(n){
					showHideNode(n);
				}).draw();
				$('#view_graph_button').remove();
			}
		}
	});

	// degree slider
	var minDegree = 0;
	var maxDegree = 0;
	if (config.graphProperties.hasOwnProperty("mindegree")) minDegree = config.graphProperties.mindegree.propValue;
	if (config.graphProperties.hasOwnProperty("maxdegree")) maxDegree = config.graphProperties.maxdegree.propValue;
	if (maxDegree > minDegree) {
		$( "#slider_degree" ).slider({
			min: minDegree,
			max: maxDegree,
			values: [ minDegree, maxDegree ],
			step: (maxDegree-minDegree)/50,
			animate: true,
			create: function(event,ui) {
				slider_degree[0] = minDegree;
				slider_degree[1] = maxDegree;
			},
			slide: function(event,ui) {
				if (ui.values[ 0 ] >= ui.values[ 1 ]) {
					return false;
				} else {
					slider_degree[0] = ui.values[ 0 ];
					slider_degree[1] = ui.values[ 1 ];
					sigma.instances[1].iterNodes(function(n){
						showHideNode(n);
					}).draw();
					$('#view_graph_button').remove();
				}
			}
		});
	} else {
		$( "#filter_degree" ).remove();
	}
	
	// in degree slider
	var minInDegree = 0;
	var maxInDegree = 0;
	if (config.graphProperties.hasOwnProperty("minindegree")) minInDegree = config.graphProperties.minindegree.propValue;
	if (config.graphProperties.hasOwnProperty("maxindegree")) maxInDegree = config.graphProperties.maxindegree.propValue;
	if (maxInDegree > minInDegree) {
		$( "#slider_indegree" ).slider({
			min: minInDegree,
			max: maxInDegree,
			values: [ minInDegree, maxInDegree ],
			step: (maxInDegree-minInDegree)/50,
			animate: true,
			create: function(event,ui) {
				slider_indegree[0] = minInDegree;
				slider_indegree[1] = maxInDegree;
			},
			slide: function(event,ui) {
				if (ui.values[ 0 ] >= ui.values[ 1 ]) {
					return false;
				} else {
					slider_indegree[0] = ui.values[ 0 ];
					slider_indegree[1] = ui.values[ 1 ];
					sigma.instances[1].iterNodes(function(n){
						showHideNode(n);
					}).draw();
					$('#view_graph_button').remove();
				}
			}
		});
	} else {
		$( "#filter_indegree" ).remove();
	}
	
	// out degree slider
	var minOutDegree = 0;
	var maxOutDegree = 0;
	if (config.graphProperties.hasOwnProperty("minoutdegree")) minOutDegree = config.graphProperties.minoutdegree.propValue;
	if (config.graphProperties.hasOwnProperty("maxoutdegree")) maxOutDegree = config.graphProperties.maxoutdegree.propValue;
	if (maxOutDegree > minOutDegree) {
		$( "#slider_outdegree" ).slider({
			min: minOutDegree,
			max: maxOutDegree,
			values: [ minOutDegree, maxOutDegree ],
			step: (maxOutDegree-minOutDegree)/50,
			animate: true,
			create: function(event,ui) {
				slider_outdegree[0] = minOutDegree;
				slider_outdegree[1] = maxOutDegree;
			},
			slide: function(event,ui) {
				if (ui.values[ 0 ] >= ui.values[ 1 ]) {
					return false;
				} else {
					slider_outdegree[0] = ui.values[ 0 ];
					slider_outdegree[1] = ui.values[ 1 ];
					sigma.instances[1].iterNodes(function(n){
						showHideNode(n);
					}).draw();
					$('#view_graph_button').remove();
				}
			}
		});
	} else {
		$( "#filter_outdegree" ).remove();
	}
	
	// betweenness slider
	var minBetweenness = 0;
	var maxBetweenness = 0;
	if (config.graphProperties.hasOwnProperty("minbetweenness")) minBetweenness = config.graphProperties.minbetweenness.propValue;
	if (config.graphProperties.hasOwnProperty("maxbetweenness")) maxBetweenness = config.graphProperties.maxbetweenness.propValue;
	if (maxBetweenness > minBetweenness) {
		$( "#slider_betweenness" ).slider({
			min: minBetweenness,
			max: maxBetweenness,
			values: [ minBetweenness, maxBetweenness ],
			step: (maxBetweenness-minBetweenness)/50,
			animate: true,
			create: function(event,ui) {
				slider_betweenness[0] = minBetweenness;
				slider_betweenness[1] = maxBetweenness;
			},
			slide: function(event,ui) {
				if (ui.values[ 0 ] >= ui.values[ 1 ]) {
					return false;
				} else {
					slider_betweenness[0] = ui.values[ 0 ];
					slider_betweenness[1] = ui.values[ 1 ];
					sigma.instances[1].iterNodes(function(n){
						showHideNode(n);
					}).draw();
					$('#view_graph_button').remove();
				}
			}
		});
	} else {
		$( "#filter_betweenness" ).remove();
	}

	// pagerank slider
	var minPageRank = 0;
	var maxPageRank = 0;
	if (config.graphProperties.hasOwnProperty("minpagerank")) minPageRank = config.graphProperties.minpagerank.propValue;
	if (config.graphProperties.hasOwnProperty("maxpagerank")) maxPageRank = config.graphProperties.maxpagerank.propValue;
	if (maxPageRank > minPageRank) {
		$( "#slider_pagerank" ).slider({
			min: minPageRank,
			max: maxPageRank,
			values: [ minPageRank, maxPageRank ],
			step: (maxPageRank-minPageRank)/50,
			animate: true,
			create: function(event,ui) {
				slider_pagerank[0] = minPageRank;
				slider_pagerank[1] = maxPageRank;
			},
			slide: function(event,ui) {
				if (ui.values[ 0 ] >= ui.values[ 1 ]) {
					return false;
				} else {
					slider_pagerank[0] = ui.values[ 0 ];
					slider_pagerank[1] = ui.values[ 1 ];
					sigma.instances[1].iterNodes(function(n){
						showHideNode(n);
					}).draw();
					$('#view_graph_button').remove();
				}
			}
		});
	} else {
		$( "#filter_pagerank" ).remove();
	}
	
	$("#layoutSelector").change(function() {
		sigInst.setLayoutMode( $(this).val() );
		$( "#slider_gravity" ).slider('value', sigInst.getgravity());
		$( "#slider_scalingRatio" ).slider('value', sigInst.getscalingRatio());
		$( "#slider_edgeWeightInfluence" ).slider('value', sigInst.getedgeWeightInfluence());
		$('input[name=strongGravity]').prop('checked', sigInst.getstrongGravityMode());
		$('input[name=attraction]').prop('checked', sigInst.getoutboundAttractionDistribution());
		$('input[name=linlog]').prop('checked', sigInst.getlinLogMode());
		$('input[name=adjustSizes]').prop('checked', sigInst.getadjustSizes());
		startLayout();
	});
	$( "#slider_gravity" ).slider({
		min: 1,
		max: 40,
		value: sigInst.getgravity(),
		step: 1,
		animate: true,
		slide: function(event,ui) {
			$("#layoutSelector").val("custom");
			startLayout();
			sigInst.setgravity(ui.value);            
			sigInst.draw();
		}
	});
	$( "#slider_scalingRatio" ).slider({
		min: 1,
		max: 20,
		value: sigInst.getscalingRatio(),
		step: 1,
		animate: true,
		slide: function(event,ui) {
			$("#layoutSelector").val("custom");
			startLayout();
			sigInst.setscalingRatio(ui.value);            
			sigInst.draw();
		}
	});
	$( "#slider_edgeWeightInfluence" ).slider({
		min: 0,
		max: 1.4,
		value: sigInst.getedgeWeightInfluence(),
		step: 0.07,
		animate: true,
		slide: function(event,ui) {
			$("#layoutSelector").val("custom");
			startLayout();
			sigInst.setedgeWeightInfluence(ui.value);            
			sigInst.draw();
		}
	});
	$('input[name=strongGravity]').prop('checked', sigInst.getstrongGravityMode());
	$('input[name=strongGravity]').change(function(){
		$("#layoutSelector").val("custom");
		startLayout();
		sigInst.setstrongGravityMode( $(this).prop('checked') );            
		sigInst.draw();
	});
	$('input[name=attraction]').prop('checked', sigInst.getoutboundAttractionDistribution());
	$('input[name=attraction]').change(function(){
		$("#layoutSelector").val("custom");
		startLayout();
		sigInst.setoutboundAttractionDistribution( $(this).prop('checked') );            
		sigInst.draw();
	});
	$('input[name=linlog]').prop('checked', sigInst.getlinLogMode());
	$('input[name=linlog]').change(function(){
		$("#layoutSelector").val("custom");
		startLayout();
		sigInst.setlinLogMode( $(this).prop('checked') );            
		sigInst.draw();
	});
	$('input[name=adjustSizes]').prop('checked', sigInst.getadjustSizes());
	$('input[name=adjustSizes]').change(function(){
		$("#layoutSelector").val("custom");
		startLayout();
		sigInst.setadjustSizes( $(this).prop('checked') );            
		sigInst.draw();
	});

	// label threshold slider
	$( "#slider_labelthreshold" ).slider({
		min: 0.1,
		max: 1.0,
		value: 0.2,
		step: 0.05,
		animate: true,
		slide: function(event,ui) {
			var sliderNodes = $("#slider_nodes").slider('value');
			sigInst.drawingProperties({ labelThreshold:  ((maxNodeSize*sliderNodes) - ((maxNodeSize*sliderNodes)-(minNodeSize*sliderNodes))*ui.value) }).draw();
		}
	});

	// node label size slider
	$( "#slider_nodelabelsize" ).slider({
		min: 0.8,
		max: 5.0,
		value: sigInst.getlabelSizeRatio(),
		step: 0.2,
		animate: true,
		slide: function(event,ui) {
			sigInst.drawingProperties({ labelSizeRatio: ui.value }).draw();
		}
	});

	// edge label size slider
	$( "#slider_edgelabelsize" ).slider({
		min: 0.8,
		max: 5.0,
		value: sigInst.getedgeLabelSizeRatio(),
		step: 0.2,
		animate: true,
		slide: function(event,ui) {
			sigInst.drawingProperties({ edgeLabelSizeRatio: ui.value }).draw();
		}
	});

	// edge label decimals slider
	$( "#slider_edgelabeldecimals" ).slider({
		min: 0,
		max: 6,
		value: sigInst.getedgeLabelDecimals(),
		step: 1,
		animate: true,
		slide: function(event,ui) {
			sigInst.drawingProperties({ edgeLabelDecimals: ui.value }).draw();
		}
	});

	var communities = [];
	sigma.instances[1].iterNodes(function(n){
		modClass = sigInst.getNodeAttr(n,'modularity_class');
		var community = {};
		if (typeof communities[modClass] == 'undefined') {
			community.id = modClass;
			community.text = modClass;
			community.nodecount = 1;
			community.color = n.color;
		} else {
			community = communities[modClass];
			community.nodecount++;
		}
		communities[modClass] = community;
	});

	function formatCommunitiesResult(result) {
		var html = '';
		html += '<div>';
		html += '<div style="width:20px; height:12px; border:1px solid #ddd; margin-right:5px; background:' + result.color + ';display:inline-block"></div>';
		html += 'Class ' + result.id + ' (' + result.nodecount + ' nodes)';
		html += '</div>';
		return (html);
	}

	function formatCommunitiesSelection(result) {
		var html = '';
		html += '<div>';
		html += '<div style="width:20px; height:12px; border:1px solid #ddd; margin-right:5px; background:' + result.color + ';display:inline-block"></div>';
		html += result.id;
		html += '</div>';
		return (html);
	}

	var previous_communities_filter = new Array();
	$("#communityfilter").select2({
		placeholder: "Community Filter",
		multiple: true,
		data:{ results: communities},
		formatSelection: formatCommunitiesSelection,
		formatResult: formatCommunitiesResult,
		escapeMarkup: function(m) { return m; },
		dropdownCssClass: "bigdrop"
	}).on('select2-close', function(e) {
		communities_filter = previous_communities_filter;
	}).on('change', function(e) {
		communities_filter = e.val;
		previous_communities_filter = communities_filter;
	}).on('select2-highlight', function(e) {
		communities_filter = previous_communities_filter.concat(new Array(e.val));
	}).on('change select2-highlight select2-close', function(e) {
		sigma.instances[1].iterNodes(function(n){
			showHideNode(n);
		}).draw();
		$('#view_graph_button').remove();
		var filterDivHeight = filterDivHeightInit + $("#s2id_communityfilter").height() - communityfilterHeightInit;
		$("#filter_div").height(filterDivHeight);
	});
	var filterDivHeightInit = $("#filter_div").height();
	var communityfilterHeightInit = $("#s2id_communityfilter").height();

	var nodes = [];
	sigma.instances[1].iterNodes(function(n){
		nodes.push({id: n.id, text: n.label, color: n.color});
	});
	
	if(attr_key !=="" && attr_value !== ""){
		if(attr_nodes.length > 0){
			for(var i=0; i<attr_nodes.length; i++){
				showActiveNode(attr_nodes[i]);
				skip = true;
			}
			for(var i=0; i<attr_nodes.length; i++){
				highlightNode(attr_nodes[i]);
			}
			$("#tabs").tabs().tabs('select', 1);
			skip = false;
		}
		else
			alert("There is no matching nodes!");
	}
	
	function compare(a,b) {
		if (a.text.toLowerCase() < b.text.toLowerCase())
			return -1;
		if (a.text.toLowerCase() > b.text.toLowerCase())
			return 1;
		return 0;
	}

	nodes.sort(compare);
	
	function formatResult(result) {
		var html = '';
		html += '<div>';
		html += '<div style="width:20px; height:12px; border:1px solid #ddd; margin-right:5px; background:' + result.color + ';display:inline-block"></div>';
		html += result.text;
		html += '</div>';
		return (html);
	}

	function formatSelection(result) {
		return result.text;
	}

	function highlightNode(nodeID) {
		//sigInst.refresh();
		sigInst._core.plotter.drawHoverNode(sigInst._core.graph.nodesIndex[nodeID]);
	}
	
	


	// Search node drop down selector
	$("#searchnodes").select2({
		placeholder: "Search for a node",
		allowClear: true,
		data:{ results: nodes},
		formatSelection: formatSelection,
		formatResult: formatResult,
		dropdownCssClass: "bigdrop"
	})
	.on('select2-highlight', function(e) {sigInst.refresh(); highlightNode(e.val); })
	.on('change', function(e) {showActiveNode(e.val); })
	;
	
	
//edge filter , added by Jackie ---begin
	function filter_edges(edgecolor) {
		showRestoreGraphButton(); 
		sigInst.iterEdges(function(a) {
			if(a.color == edgecolor)
			{
				a.hidden = 0;
			}
			else
			{
				a.hidden = 1;
			}
		}).draw();
	}

    var edgelegends = [];
    for(i=0;i<config.edgecolor.length;i++) 
    {
        edgelegends.push({ 
        		id : i,
            text: config.edgecolor[i].edgetype,
            color: config.edgecolor[i].color
       	})
     };

    $("#edgelegend").select2({
        placeholder: "Edge color legend",
        allowClear: true,
        data: {results: edgelegends},
        formatSelection: formatSelection,
        formatResult:formatResult,
        dropdownCssClass: "bigdrop"
    }).on("change",function(a) {filter_edges(edgelegends[a.val].color)})
    ;
    
 //edge filter , added by Jackie ---end
 
 

	//jquery qtip (tooltip) for all divs
	$('div').on('mouseover', 'div.helptip[title]', function(event) {
		$(this).qtip({
			position: {
				//target: 'mouse',
//				at: 'bottom center'
				at: 'bottom left',
				adjust: {
					x: 10
				}
			},
			show: {
				delay: 1000,
				ready: true // Need this to make it show on first mouseover
			}
		}).css('cursor','help'); // show mouse arrow with a question-mark for tooltips
	});
	$(document).on('mouseover', '.titletip[title]', function(event) {
		$(this).qtip({
			position: {
				at: 'bottom left',
				adjust: {
					x: 10
				}
			},
			show: {
				delay: 1000,
				ready: true // Need this to make it show on first mouseover
			}
		});
	});

	// Activate the plugin that allows the end user to drag a node and place it in a new location.
	sigInst.activateDragNode();
}