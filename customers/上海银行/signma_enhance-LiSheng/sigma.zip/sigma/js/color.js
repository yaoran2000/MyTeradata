String.prototype.hashCode = function(){
	var hash = 0, i, char;
	if (this.length == 0) return hash;
	for (i = 0, l = this.length; i < l; i++) {
		char  = this.charCodeAt(i);
		hash  = ((hash<<5)-hash)+char;
		hash |= 0; // Convert to 32bit integer
	}
	return hash;
};

function decimalToHexString(number)
{
	if (number < 0)
	{
		number = 0xFFFFFFFF + number + 1;
	}

	str = number.toString(16).toUpperCase() + "";
	var pad = "00";
	return(pad.substring(0, pad.length - str.length) + str);	
}

function getRandomColor(seed, hsb) {
	var m = new MersenneTwister(seed.hashCode());
	
	var hue, saturation, brightness;

	// default HSB values if it's not passed into the function
	if (typeof hsb === 'undefined') {
		hsb = {
			// Set hue. Value should be between 0.0 and 1.0
			minHue : 0.0,
			maxHue : 1.0,

			// Set saturation. Must be between 0.0 and 1.0
			minSaturation : 0.60,
			maxSaturation : 1.00,
			
			// Set brightness. Must be between 0.0 and 1.0
			minBrightness : 0.80,
			maxBrightness : 1.00			
		};
	}

	hue = parseFloat(hsb.minHue) + (m.random() * ((parseFloat(hsb.maxHue) - parseFloat(hsb.minHue))));
	saturation = parseFloat(hsb.minSaturation) + (m.random() * ((parseFloat(hsb.maxSaturation) - parseFloat(hsb.minSaturation))));
	brightness = parseFloat(hsb.minBrightness) + (m.random() * ((parseFloat(hsb.maxBrightness) - parseFloat(hsb.minBrightness))));

	var rgb = HSVtoRGB(hue, saturation, brightness);
	return rgb;
}


/* accepts parameters
 * h  Object = {h:x, s:y, v:z}
 * OR 
 * h, s, v
 * h, s, v all must be between 0.0 and 1.0, inclusive
 */
function HSVtoRGB(h, s, v) {
	var r, g, b, i, f, p, q, t;
	if (h && s === undefined && v === undefined) {
		s = h.s, v = h.v, h = h.h;
	}
	i = Math.floor(h * 6);
	f = h * 6 - i;
	p = v * (1 - s);
	q = v * (1 - f * s);
	t = v * (1 - (1 - f) * s);
	switch (i % 6) {
	case 0: r = v, g = t, b = p; break;
	case 1: r = q, g = v, b = p; break;
	case 2: r = p, g = v, b = t; break;
	case 3: r = p, g = q, b = v; break;
	case 4: r = t, g = p, b = v; break;
	case 5: r = v, g = p, b = q; break;
	}
	var rgb =
		(
				"#" +
				decimalToHexString (Math.floor(r * 255)) +
				decimalToHexString (Math.floor(g * 255)) +
				decimalToHexString (Math.floor(b * 255))
		);
	return rgb;
}