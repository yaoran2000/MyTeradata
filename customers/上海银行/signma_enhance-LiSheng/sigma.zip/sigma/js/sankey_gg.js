function endsWith(str, suffix) {
	return str.indexOf(suffix, str.length - suffix.length) !== -1;
}

function init(config) {

	// Load Sankey data from JSON file
	var dataFile = config.data;
	jsonhttp = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

	// process JSON file as uncompressed
	if (endsWith(dataFile, ".json")) {
		jsonhttp.overrideMimeType('text/xml');
		jsonhttp.open('GET', dataFile, false);
		jsonhttp.send();
		data = $.parseJSON( jsonhttp.responseText );
	}

	// process JSON file as a ZIP file
	else if (endsWith(dataFile, ".zip")) {
		jsonhttp.overrideMimeType('text/plain; charset=x-user-defined');
		jsonhttp.open('GET', dataFile, false);
		jsonhttp.send();
		var zip = new JSZip(jsonhttp.responseText);
		jsonFileName = dataFile.substring(0,dataFile.indexOf(".zip"));
		rawJSON = zip.file(jsonFileName).asText(); // JSON in text format
		data = $.parseJSON( rawJSON );// convert JSON text to JSON document object
	}

	// Collapse control panel when title is clicked
	animatedcollapse.addDiv('controls', 'hide=1');
	animatedcollapse.ontoggle=function($, divobj, state){ };
	animatedcollapse.init();

	// Set html and header title
	$('.pagetitle').text(config.text.title);
	$('.pagesubtitle').text(config.text.subtitle);

	$(document).ready(function() {
		sankey = new Sankey();
				
		sankey.box_hover_start_callback = function(box) {
			$("#sankey").css("cursor","help").attr("title", "Click for Properties");
			$("#sankey").click(function(e) {
				var maxHeight = $(window).height()/2 - 50;
				var top = e.pageY;
				var left = e.pageX;
				$("#boxPropertiesParent")
				.html(
						$("<div/>")
						.attr("id", "boxProperties")
						.css("position", "absolute")
						.css("overflow-y", "auto")
						.css("max-height", maxHeight)
						.css("top", top)
						.css("left", left)
						.css("background", "rgba(235,235,235,0.93)")
						.addClass("divborder")
				);

				var inFlow = box.flow_side("left");
				var outFlow = box.flow_side("right");
				var dropOff = inFlow - outFlow;
				
				// add standard (derived) properties to properties pane
				proprow("boxProperties", "Name", formatVal(box.label_text, "string"), "boxProperties_" + "name", "string");
				proprow("boxProperties", "Column Position", formatVal(box.stack+1, "float"), "boxProperties_" + "stack", "float");
				if (!box.is_left_box())
					proprow("boxProperties", "In Flow", formatVal(inFlow, "float"), "boxProperties_" + "left", "float");
				if (!box.is_right_box())
					proprow("boxProperties", "Out Flow", formatVal(outFlow, "float"), "boxProperties_" + "right", "float");
				if (dropOff >= 0 && !box.is_left_box() && !box.is_right_box()) {
					var dropoffString = dropOff + " (" + (100*dropOff/inFlow).toFixed(0) + "%)";
					proprow("boxProperties", "Dropoff", formatVal(dropoffString, "string"), "boxProperties_" + "dropoff", "string");
				}
				if (!box.is_left_box())
					proprow("boxProperties", "Entry Pathways", formatVal(box.flow_count_side("left"), "float"), "boxProperties_" + "entry_pathways", "float");
				if (!box.is_right_box())
					proprow("boxProperties", "Exit Pathways", formatVal(box.flow_count_side("right"), "float"), "boxProperties_" + "exit_pathways", "float");

				// add custom properties (such as via multi input) to properties pane
				for (var attribute in box.attributes) {
					var key = attribute;
					var value = box.attributes[attribute];
					var title = data.sankey.attributeDefinitions[key].title;
					var type = data.sankey.attributeDefinitions[key].type;
					proprow("boxProperties", title, formatVal(value, type), "boxProperties_" + key, type);
				}
				
				// reposition box up or left if it's flowing off screen
				var boxHeight = $("#boxProperties").height() + 30;
				var boxWidth = $("#boxProperties").width() + 30;
				var windowHeight = $(window).height();
				var windowWidth = $(window).width();
				if (top + boxHeight > windowHeight) {			
					top = top - (top + boxHeight - windowHeight);
					$("#boxProperties").css("top", top);
				}
				if (left + boxWidth > windowWidth) {
					left = left - (left + boxWidth - windowWidth);
					$("#boxProperties").css("left", left);
				}
				// javrach 2014-jan-8
				// Once the properties pane height has been automatically determined, with a max height of maxHeight, explicitly set the height.
				// This is necessary when we have custom properties containing long text that get the more/less expander. Sometimes, 
				// clicking on "more" can have the effect of increasing the height of the props pane, which we don't want.
				// Thus, explicitly setting height avoids this issue.
				$("#boxProperties").css("height", $("#boxProperties").height());
			});			
		};

		sankey.box_hover_end_callback = function(box) {
			// change help mouse pointer back to default
			$("#sankey").css("cursor","default").removeAttr("title");
			
			// remove click event
			$("#sankey" ).off();

			// remove box properties when user clicks on background
			$( "#sankey" ).click(function() {
				$("#boxProperties").remove();
			});
		};

		sankey.convert_box_description_labels_callback = function(name) {
			var alternative_name = data.sankey.name_conversions[name];
			if(alternative_name == null) alternative_name = name;
			return alternative_name;
		};

		sankey.box_attributes_callback = function(name) {
			var attributes = data.sankey.attributeValues[name];
			return attributes;
		};

		for (var i = 0; i < data.sankey.stack.length; i++) {
			sankey.stack(i, data.sankey.stack[i]);
		}

		desired_sankey_height = $(window).height();
		sankey.y_space = desired_sankey_height/16;
		$(window).bind('resize',function(){
			sankey.display_width = $('#sankey').width();
			sankey.display_height = $(window).height() - sankey.height_offset ;
			desired_sankey_height = $(window).height();
			sankey.y_space = desired_sankey_height/16*$( "#slider_y" ).slider( "value" );
			$("#sankey > svg").css("width", sankey.display_width);
			$("#sankey > svg").css("height", sankey.display_height);
			sankey.redraw();
		});
		scoreMax = config.graphProperties.maxedge.propValue; // actual edge size, max
		scoreMin = config.graphProperties.minedge.propValue; // actual edge size, min
		widthMax = config.sankey.displayProperties.maxEdgeSize; // max edge display size
		widthMin = config.sankey.displayProperties.minEdgeSize; // min edge display size
		sankey.convert_flow_values_callback = function(flow) {
			if (scoreMax == scoreMin)
				return widthMax;
			else
				return (widthMin + (flow-scoreMin)*(widthMax-widthMin)/(scoreMax-scoreMin) );
		};
		sankey.min_threshold_for_drawing = sankey.convert_flow_values_callback(scoreMin);
		sankey.max_threshold_for_drawing = sankey.convert_flow_values_callback(scoreMax);
		function roundNumber(num, dec) {
			var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
			return result;
		}
		sankey.convert_flow_labels_callback = function(flow) {
			return roundNumber(flow,2);
		};
		var hsb = {
				// Set hue. Value should be between 0.0 and 1.0.
				minHue : 0.0,
				maxHue : 1.0,

				// Set saturation. Must be between 0.0 and 1.0
				minSaturation : 0.60,
				maxSaturation : 1.00,
				
				// Set brightness. Must be between 0.0 and 1.0
				minBrightness : 0.80,
				maxBrightness : 1.00
			};
		sankey.setColors(data.sankey.name_conversions, hsb);
		sankey.setData(data.sankey.data);

		// Draw sankey unless sankey is empty, in which case we show an error message.
		if (sankey.getNumberLines() == 0) {
			$("#sankey").html(''
					+ '<div class="center" style="margin-top: 80px; width: 600px; text-align:center;">'
					+ '   <h2>This visualization is empty.</h2>'
					+ '   <h3>Check your input data and re-run.</h3>'
					+ '</div>'
			);
		} else {
			sankey.draw();
		}
				
		// sankey colors
		$( "#slider_colors" ).slider({
			min: 1,
			max: 100,
			value: sankey.color_seed,
			step: 1,
			animate: true,
			slide: function(event,ui) {
				sankey.color_seed = ui.value;
				sankey.setColors(data.sankey.name_conversions, hsb);
				sankey.redraw();
			}
		});
		
		$( "#slider_colors_hue" ).slider({
			range: true,
			min: 0,
			max: 1,
			values: [ hsb.minHue, hsb.maxHue ],
			step: 0.05,
			animate: true,
			slide: function(event,ui) {
				if (ui.values[ 0 ] == ui.values[ 1 ]) {
					return false;
				} else {
					hsb.minHue = [ ui.values[ 0 ] ];
					hsb.maxHue = [ ui.values[ 1 ] ];
					sankey.setColors(data.sankey.name_conversions, hsb);
					sankey.redraw();
				}
			}
		});
		
		$( "#slider_colors_saturation" ).slider({
			range: true,
			min: 0,
			max: 1,
			values: [ hsb.minSaturation, hsb.maxSaturation ],
			step: 0.05,
			animate: true,
			slide: function(event,ui) {
				if (ui.values[ 0 ] == ui.values[ 1 ]) {
					return false;
				} else {
					hsb.minSaturation = [ ui.values[ 0 ] ];
					hsb.maxSaturation = [ ui.values[ 1 ] ];
					sankey.setColors(data.sankey.name_conversions, hsb);
					sankey.redraw();
				}
			}
		});
		
		$( "#slider_colors_brightness" ).slider({
			range: true,
			min: 0,
			max: 1,
			values: [ hsb.minBrightness, hsb.maxBrightness ],
			step: 0.05,
			animate: true,
			slide: function(event,ui) {
				if (ui.values[ 0 ] == ui.values[ 1 ]) {
					return false;
				} else {
					hsb.minBrightness = [ ui.values[ 0 ] ];
					hsb.maxBrightness = [ ui.values[ 1 ] ];
					sankey.setColors(data.sankey.name_conversions, hsb);
					sankey.redraw();
				}
			}
		});
		
		// sankey y spacing slider
		$( "#slider_y" ).slider({
			min: 0.1,
			max: 2,
			value: 1,
			step: 0.1,
			animate: true,
			slide: function(event,ui) {
				sankey.y_space = desired_sankey_height/16*ui.value;
				sankey.redraw();
			}
		});
		
		// sankey box width slider
		$( "#slider_boxwidth" ).slider({
			min: -50,
			max: 100,
			value: 0,
			step: 5,
			animate: true,
			slide: function(event,ui) {
				sankey.left_margin = ui.value+ $("#slider_lmargin").slider('value');
				sankey.right_margin = sankey.default_right_margin-$("#slider_rmargin").slider('value')+2*ui.value;
				sankey.box_width = ui.value+sankey.default_box_width;
				sankey.redraw();
			}
		});
		
		// sankey box font slider
		$( "#slider_boxfont" ).slider({
			min: -2,
			max: 20,
			value: 0,
			step: 2,
			animate: true,
			slide: function(event,ui) {
				sankey.box_font_size = ui.value+sankey.default_box_font_size;
				sankey.redraw();
			}
		});
		
		// sankey number font slider
		$( "#slider_numberfont" ).slider({
			min: -2,
			max: 20,
			value: 0,
			step: 2,
			animate: true,
			slide: function(event,ui) {
				sankey.number_font_size = ui.value+sankey.default_number_font_size;
				sankey.redraw();
			}
		});
		
		// sankey left margin slider
		$( "#slider_lmargin" ).slider({
			min: sankey.default_left_margin-100,
			max: sankey.default_left_margin+100,
			value: sankey.default_left_margin,
			step: 10,
			animate: true,
			slide: function(event,ui) {
				sankey.left_margin = ui.value+$("#slider_boxwidth").slider('value');
				sankey.redraw();
			}
		});
		
		// sankey right margin slider
		$( "#slider_rmargin" ).slider({
			min: -100,
			max: 100,
			value: 0,
			step: 10,
			animate: true,
			slide: function(event,ui) {
				sankey.right_margin = sankey.default_right_margin-ui.value+2*$("#slider_boxwidth").slider('value');
				sankey.redraw();
			}
		});

		// setup min/max width slider scale array
		var widthStep = 5; // how much to increase or decrease line width with each slider step
		var minWidthMin; // absolute minimum for line width
		if ((widthMin-60) < 1) {
			minWidthMin=1;
		} else {
			minWidthMin=widthMin-60;
		}
		var maxWidthMax = widthMax+140; // absolute maximum for line width
		var widthValues = []; // array of slider minmax values

		var currVal = widthMin;
		widthValues.unshift(currVal);
		while (currVal > minWidthMin) {
			currVal = currVal - widthStep;
			if (currVal < minWidthMin) { currVal=minWidthMin; }
			widthValues.unshift(currVal);
		}
		currVal = widthMin;
		while (currVal < widthMax) {
			currVal = currVal + widthStep;
			if (currVal > widthMax) { currVal=widthMax; }
			widthValues.push(currVal);
		}
		currVal = widthMax;
		while (currVal < maxWidthMax) {
			currVal = currVal + widthStep;
			widthValues.push(currVal);
		}

		$( "#slider_widthMinMax" ).slider({
			range: true,
			min: 0,
			max: widthValues.length-1,
			values: [ widthValues.indexOf(widthMin), widthValues.indexOf(widthMax) ],
			step: 1,
			animate: true,
			slide: function(event,ui) {
				if (ui.values[ 0 ] == ui.values[ 1 ]) {
					return false;
				} else {
					widthMin=widthValues[ ui.values[ 0 ] ];
					widthMax=widthValues[ ui.values[ 1 ] ];
					sankey.min_threshold_for_drawing = sankey.convert_flow_values_callback($( "#slider_filter" ).slider( "values", 0 ));
					sankey.max_threshold_for_drawing = sankey.convert_flow_values_callback($( "#slider_filter" ).slider( "values", 1 ));
					sankey.redraw();
				}
			}
		});
		
		// sankey range filter slider
		function filterSlide(min,max) {
			sankey.min_threshold_for_drawing = sankey.convert_flow_values_callback(min);
			sankey.max_threshold_for_drawing = sankey.convert_flow_values_callback(max);
			$( "#amount_left" ).val(min);
			$( "#amount_right" ).val(max);
			sankey.redraw();
		}
		$( "#slider_filter" ).slider({
			range: true,
			min: scoreMin,
			max: scoreMax,
			values: [ scoreMin, scoreMax ],
			step: 1,
			animate: true,
			slide: function(event,ui) {
				filterSlide(ui.values[ 0 ],ui.values[ 1 ]);
			}
		});
		$( "#amount_left" ).val( $( "#slider_filter" ).slider( "values", 0 ) );
		$( "#amount_right" ).val( $( "#slider_filter" ).slider( "values", 1 ) );
		$("#amount_left").change(function () {
			if (this.value >= scoreMin &&
					this.value <= scoreMax &&
					this.value <= $("#slider_filter").slider("values", 1)) {
				$("#slider_filter").slider("values", 0, this.value);
				filterSlide(this.value, $("#slider_filter").slider("values", 1));
			} else {
				this.value = $("#slider_filter").slider("values", 0);
			}
		});
		$("#amount_right").change(function () {
			if (this.value >= scoreMin &&
					this.value <= scoreMax &&
					this.value >= $("#slider_filter").slider("values", 0)) {
				$("#slider_filter").slider("values", 1, this.value);
				filterSlide($("#slider_filter").slider("values", 0), this.value);
			} else {
				this.value = $("#slider_filter").slider("values", 1);
			}
		});
		$(".layoutSelector").change(function() {
			if ($(this).val() === 'noselect') {
				$(this).val(previous);
			}
			else {
				previous = $(this).val();
				sankey.line_label_mode = $(this).val();
				sankey.redraw();
			}
		});

		//jquery qtip (tooltip) for all divs
		$('div').on('mouseover', 'div.helptip[title]', function(event) {
			$(this).qtip({
				position: {
					//target: 'mouse',
//					at: 'bottom center'
					at: 'bottom left',
					adjust: {
						x: 10
					}
				},
				show: {
					delay: 1000,
					ready: true // Need this to make it show on first mouseover
				}
			}).css('cursor','help'); // show mouse arrow with a question-mark for tooltips
		});
		
		$(document).on('mouseover', '.titletip[title]', function(event) {
			$(this).qtip({
				position: {
					at: 'bottom left',
					adjust: {
						x: 10
					}
				},
				show: {
					delay: 200,
					ready: true // Need this to make it show on first mouseover
				}
			});
		});
		
		// tab configuration
		$(function() {
			$('#tabs').tabs();
			$('#tabs').tabs().removeClass('ui-widget');
			$('#tabs ul .ui-widget-header').tabs().attr('background','');
			$('#tabs').tabs({
				show: function(event, ui){
					// do something when changing tabs
				}
			});
		});
		
		// Download zip file link
		// If the manifest JSON file exists, show the div.
		// Otherwise, hide it (such as for visuals generated before this feature existed).
		if (!(urlExists(getManifestName(idParam))))
			$('#download_zip_div').hide();
		else
			$('#download_zip').attr('href', 'javascript:createZip("' + idParam + '")');

		///////////////////////////
		// setup graph properties pane
		///////////////////////////
		// Round a number to specified significant figures
		Math.sig = function (num, sig) {
			if (num == 0)
				return 0;
			if (Math.round(num) == num)
				return num;
			if (num < 10)
				return num.toFixed(sig);
			var digits = Math.round((-Math.log(Math.abs(num)) / Math.LN10) + (sig || 2)); //round to significant digits (sig)
			if (digits < 0)
				digits = 0;
			return num.toFixed(digits);
		};

		var modalID = 0;
		var proprowToggle = 0;
		$.each(config.graphProperties, function(key, value) {
			if (value.propValue != null)
				proprow("graphproperties", value.propLabel, formatVal(value.propValue, value.propDataType), "graphproperties_" + key, value.propDataType);
		});
		
		function formatVal (value, datatype) {
			if (datatype == 'float' || datatype == 'double') { return (Math.sig(Number(value),6)); }
			else if (datatype == 'long') { return (Number(value).toPrecision(4)); }
			else if (datatype == 'string') { return value.replace(/&#10;/g,"<br>"); }
			else { return value; }
		}

		// escape a DIV ID so it complies with HTML spec (e.g. no spaces)
		function escapeID(str) {
			return str.replace(/([;&,\.\+\*\~':"\!\^#$%@\[\]\(\)=>\|])/g, '\\$1').replace(/ /g, '_');
		}

		function proprow (divid, propname, propvalue, propvalueid, datatype) {
			propvalueid = escapeID(propvalueid);
			html = '';
			if (proprowToggle == 0) {
				html += '<div class="proprow">';
				proprowToggle++;
			} else {
				html += '<div class="proprow proprowgray">';
				proprowToggle--;
			}

			// long strings need special formatting, e.g. put on their own row with expander
			if (datatype == 'string' && propvalue.length > 24)
				isExpander = true;
			else
				isExpander = false;
			if (isExpander) {
				modalLink = '<a href="#" data-animation="none" data-reveal-id="modalPopup_' + ++modalID + '"><img title="View full text" class="titletip left-image" style="height: 16px;" src="img/popup.png"></a>';
				expanderPropvalue = '<div class="expander">' + propvalue + '</div>';
				html += '   <div class="helptip">' + propname + '</div>';
				html += '   <div id="' + propvalueid + '">' + modalLink + expanderPropvalue + '</div>';
			}
			else {
				html += '   <div class="propname helptip">' + propname + '</div>';
				html += '   <div id="' + propvalueid + '" class="propvalue">' + propvalue + '</div>';
			}
			html += '</div>';
			$('#' + divid).append(html);

			if (isExpander) {
				// Create a div for the modal popup if it doesn't already exist.
				// Once we know it exists, append the actual text (propvalue) to the div.
				modalDivID = "modal_" + divid;
				if ($('#' + modalDivID).length === 0) {
					$('#modalParent').append('   <div id="' + modalDivID + '"></div>');
				}
				$('#' + modalDivID).append('   <div id="modalPopup_' + modalID + '" class="reveal-modal">' + propvalue + ' <a class="close-reveal-modal">&#215;</a></div>');


				$('div.expander').expander({
					afterExpand: function() {
						$(this).find('.details').css({display: 'inline'});
						//resizeProperties();
					},
					afterCollapse: function() {
						//resizeProperties();
					},
					slicePoint: 50,
					widow: 2,
					expandSpeed: 0,
					collapseSpeed: 0,
					expandText: '<span class="expander-link">[more]</span>',
					expandPrefix: ' ... ',
					userCollapseText: '<span class="expander-link">[less]</span>'
				});
			}
		}
		
	});
}
