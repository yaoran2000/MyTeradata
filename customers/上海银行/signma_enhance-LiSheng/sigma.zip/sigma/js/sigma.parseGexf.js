//seeded random function
(function(j,i,g,m,k,n,o){function q(b){var e,f,a=this,c=b.length,d=0,h=a.i=a.j=a.m=0;a.S=[];a.c=[];for(c||(b=[c++]);d<g;)a.S[d]=d++;for(d=0;d<g;d++)e=a.S[d],h=h+e+b[d%c]&g-1,f=a.S[h],a.S[d]=f,a.S[h]=e;a.g=function(b){var c=a.S,d=a.i+1&g-1,e=c[d],f=a.j+e&g-1,h=c[f];c[d]=h;c[f]=e;for(var i=c[e+h&g-1];--b;)d=d+1&g-1,e=c[d],f=f+e&g-1,h=c[f],c[d]=h,c[f]=e,i=i*g+c[e+h&g-1];a.i=d;a.j=f;return i};a.g(g)}function p(b,e,f,a,c){f=[];c=typeof b;if(e&&c=="object")for(a in b)if(a.indexOf("S")<5)try{f.push(p(b[a],e-1))}catch(d){}return f.length?f:b+(c!="string"?"\0":"")}function l(b,e,f,a){b+="";for(a=f=0;a<b.length;a++){var c=e,d=a&g-1,h=(f^=e[a&g-1]*19)+b.charCodeAt(a);c[d]=h&g-1}b="";for(a in e)b+=String.fromCharCode(e[a]);return b}i.seedrandom=function(b,e){var f=[],a;b=l(p(e?[b,j]:arguments.length?b:[(new Date).getTime(),j,window],3),f);a=new q(f);l(a.S,j);i.random=function(){for(var c=a.g(m),d=o,b=0;c<k;)c=(c+b)*g,d*=g,b=a.g(1);for(;c>=n;)c/=2,d/=2,b>>>=1;return(c+b)/d};return b};o=i.pow(g,m);k=i.pow(2,k);n=k*2;l(i.random(),j)})([],Math,256,6,52);

//Mathieu Jacomy @ Sciences Po Médialab & WebAtlas
//(requires sigma.js to be loaded)
function endsWith(str, suffix) {
	return str.indexOf(suffix, str.length - suffix.length) !== -1;
}

sigma.publicPrototype.parseGexf = function(gexfPath, attr_key, attr_value, attr_nodes) {
	// Load XML file:
	var gexfhttp, gexf;
	var sigmaInstance = this;
	gexfhttp = window.XMLHttpRequest ?
			new XMLHttpRequest() :
				new ActiveXObject('Microsoft.XMLHTTP');

			// process GEXF file as a regular GEXF (i.e. not a ZIP file)
			if (endsWith(gexfPath, ".gexf")) {
				gexfhttp.overrideMimeType('text/xml');
				gexfhttp.open('GET', gexfPath, false);
				gexfhttp.send();
				gexf = gexfhttp.responseXML;
			} 
			
			// process GEXF file as a ZIP file
			else if (endsWith(gexfPath, ".zip")) {
				gexfhttp.overrideMimeType('text/plain; charset=x-user-defined');
				gexfhttp.open('GET', gexfPath, false);
				gexfhttp.send();
				var zip = new JSZip(gexfhttp.responseText);
				gexfFileName = gexfPath.substring(0,gexfPath.indexOf(".zip"));
				rawGEXF = zip.file(gexfFileName).asText(); // GEXF in text format
				gexf = $.parseXML( rawGEXF );// convert GEXF text to GEXF XML document object
			}

			var viz='http://www.gexf.net/1.2draft/viz'; // Vis namespace
			var i, j, k;

			// Parse Attributes
			// This is confusing, so I'll comment heavily
			var nodesAttributes = [];   // The list of attributes of the nodes of the graph that we build in json
			var edgesAttributes = [];   // The list of attributes of the edges of the graph that we build in json
			var attributesNodes = gexf.getElementsByTagName('attributes');  // In the gexf (that is an xml), the list of xml nodes 'attributes' (note the plural 's')

			for(i = 0; i<attributesNodes.length; i++){
				var attributesNode = attributesNodes[i];  // attributesNode is each xml node 'attributes' (plural)

				if(attributesNode.getAttribute('class') == 'node'){
					var attributeNodes = attributesNode.getElementsByTagName('attribute');  // The list of xml nodes 'attribute' (no 's')
					for(j = 0; j<attributeNodes.length; j++){
						var attributeNode = attributeNodes[j];  // Each xml node 'attribute'

						var id = attributeNode.getAttribute('id'),
						title = attributeNode.getAttribute('title'),
						type = attributeNode.getAttribute('type');

						var attribute = {id:id, title:title, type:type};
						nodesAttributes.push(attribute);

					}
					sigmaInstance.addNodeAttributes(nodesAttributes);
				} else if(attributesNode.getAttribute('class') == 'edge'){
					var attributeNodes = attributesNode.getElementsByTagName('attribute');  // The list of xml nodes 'attribute' (no 's')
					for(j = 0; j<attributeNodes.length; j++){
						var attributeNode = attributeNodes[j];  // Each xml node 'attribute'

						var id = attributeNode.getAttribute('id'),
						title = attributeNode.getAttribute('title'),
						type = attributeNode.getAttribute('type');

						var attribute = {id:id, title:title, type:type};
						edgesAttributes.push(attribute);

					}
					sigmaInstance.addEdgeAttributes(edgesAttributes);
				}
			}

			// added by javrach 2012-07-07
			var graphElement = gexf.getElementsByTagName('graph');
			var graphDirection = graphElement[0].getAttribute('defaultedgetype');
			setGraphDirection(graphDirection);

			var nodes = []; // The nodes of the graph
			var nodesNodes = gexf.getElementsByTagName('nodes') // The list of xml nodes 'nodes' (plural)

			for(i=0; i<nodesNodes.length; i++){
				var nodesNode = nodesNodes[i];  // Each xml node 'nodes' (plural)
				var nodeNodes = nodesNode.getElementsByTagName('node'); // The list of xml nodes 'node' (no 's')

				for(j=0; j<nodeNodes.length; j++){
					var nodeNode = nodeNodes[j];  // Each xml node 'node' (no 's')

					window.NODE = nodeNode;

					var id = nodeNode.getAttribute('id');
					var label = nodeNode.getAttribute('label') || id;

					//viz
					Math.seedrandom(label);
					var size = 1;
					var x = 100 - 200*Math.random();
					var y = 100 - 200*Math.random();
					var color;

					var sizeNodes = nodeNode.getElementsByTagName('size');
					sizeNodes = sizeNodes.length ? 
							sizeNodes : 
								nodeNode.getElementsByTagNameNS('*','size');
					if(sizeNodes.length>0){
						sizeNode = sizeNodes[0];
						size = parseFloat(sizeNode.getAttribute('value'));
					}

					var positionNodes = nodeNode.getElementsByTagName('position');
					positionNodes = positionNodes.length ? 
							positionNodes : 
								nodeNode.getElementsByTagNameNS('*','position');
					if(positionNodes.length>0){
						var positionNode = positionNodes[0];
						x = parseFloat(positionNode.getAttribute('x'));
						y = parseFloat(positionNode.getAttribute('y'));
					}

					var colorNodes = nodeNode.getElementsByTagName('color');
					colorNodes = colorNodes.length ? 
							colorNodes : 
								nodeNode.getElementsByTagNameNS('*','color');
					if(colorNodes.length>0){
						colorNode = colorNodes[0];
						color = '#'+sigma.tools.rgbToHex(parseFloat(colorNode.getAttribute('r')),
								parseFloat(colorNode.getAttribute('g')),
								parseFloat(colorNode.getAttribute('b')));
					}

					// Create Node
					var node = {label:label, size:size, x:x, y:y, attributes:[], color:color};  // The graph node

					// Attribute values
					var attvalueNodes = nodeNode.getElementsByTagName('attvalue');
					for(k=0; k<attvalueNodes.length; k++){
						var attvalueNode = attvalueNodes[k];
						var attr = attvalueNode.getAttribute('for');
						var val = attvalueNode.getAttribute('value');
						node.attributes.push({attr:attr, val:val});
						if(attr === attr_key && val === attr_value)
							attr_nodes.push(id);
					}
					sigmaInstance.addNode(id,node);
				}
			}

			var edges = [];
			var edgeId = 0;
			var edgesNodes = gexf.getElementsByTagName('edges');
			for(i=0; i<edgesNodes.length; i++){
				var edgesNode = edgesNodes[i];
				var edgeNodes = edgesNode.getElementsByTagName('edge');
				for(j=0; j<edgeNodes.length; j++){
					var edgeNode = edgeNodes[j];
					var source = edgeNode.getAttribute('source');
					var target = edgeNode.getAttribute('target');
					var label = edgeNode.getAttribute('label');

					// added by javrach 2012-05-29
					// set edge color based on viz: attribute in edge
					var color = "";
					var colorEdges = edgeNode.getElementsByTagName('color');
					colorEdges = colorEdges.length ?
							colorEdges :
								edgeNode.getElementsByTagNameNS('*','color');
					if(colorEdges.length>0){
						colorEdge = colorEdges[0];
						color = '#'+sigma.tools.rgbToHex(parseFloat(colorEdge.getAttribute('r')),
								parseFloat(colorEdge.getAttribute('g')),
								parseFloat(colorEdge.getAttribute('b')));
					}


					var edge = {
							id:         j,
							sourceID:   source,
							targetID:   target,
							label:      label,
							attributes: [],
							color: color // added by javrach 2012-05-29 for edge color
					};

					var weight = edgeNode.getAttribute('weight');
					if(weight!=undefined){
						edge['weight'] = weight;
					}

					var attvalueNodes = edgeNode.getElementsByTagName('attvalue');
					for(k=0; k<attvalueNodes.length; k++){
						var attvalueNode = attvalueNodes[k];
						var attr = attvalueNode.getAttribute('for');
						var val = attvalueNode.getAttribute('value');
						edge.attributes.push({attr:attr, val:val});
					}

					sigmaInstance.addEdge(edgeId++,source,target,edge);
				}
			}
};
