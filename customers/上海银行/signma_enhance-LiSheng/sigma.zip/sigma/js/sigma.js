var debug = !1,
    graphDirection = "undirected";

function setGraphDirection(k) {
    graphDirection = k
}
var sigma = {
    tools: {},
    classes: {},
    instances: {}
};
(function() {
    Array.prototype.some || (Array.prototype.some = function(k, q) {
        var h = this.length;
        if ("function" != typeof k) throw new TypeError;
        for (var l = 0; l < h; l++)
            if (l in this && k.call(q, this[l], l, this)) return !0;
        return !1
    });
    Array.prototype.forEach || (Array.prototype.forEach = function(k, q) {
        var h = this.length;
        if ("function" != typeof k) throw new TypeError;
        for (var l = 0; l < h; l++) l in this && k.call(q, this[l], l, this)
    });
    Array.prototype.map || (Array.prototype.map = function(k, q) {
        var h = this.length;
        if ("function" != typeof k) throw new TypeError;
        for (var l = Array(h), m = 0; m < h; m++) m in this && (l[m] = k.call(q, this[m], m, this));
        return l
    });
    Array.prototype.filter || (Array.prototype.filter = function(k, q) {
        var h = this.length;
        if ("function" != typeof k) throw new TypeError;
        for (var l = [], m = 0; m < h; m++)
            if (m in this) {
                var z = this[m];
                k.call(q, z, m, this) && l.push(z)
            }
        return l
    });
    Object.keys || (Object.keys = function() {
        var k = Object.prototype.hasOwnProperty,
            q = !{
                toString: null
            }.propertyIsEnumerable("toString"),
            h = "toString toLocaleString valueOf hasOwnProperty isPrototypeOf propertyIsEnumerable constructor".split(" "),
            l = h.length;
        return function(m) {
            if ("object" !== typeof m && "function" !== typeof m || null === m) throw new TypeError("Object.keys called on non-object");
            var z = [],
                A;
            for (A in m) k.call(m, A) && z.push(A);
            if (q)
                for (A = 0; A < l; A++) k.call(m, h[A]) && z.push(h[A]);
            return z
        }
    }())
})();
sigma.classes.Cascade = function() {
    this.p = {};
    this.config = function(k, q) {
        if ("string" == typeof k && void 0 == q) return this.p[k];
        var h = "object" == typeof k && void 0 == q ? k : {};
        "string" == typeof k && (h[k] = q);
        for (var l in h) void 0 != this.p[l] && (this.p[l] = h[l]);
        return this
    }
};
sigma.classes.EventDispatcher = function() {
    var k = {},
        q = this;
    this.one = function(h, l) {
        if (!l || !h) return q;
        ("string" == typeof h ? h.split(" ") : h).forEach(function(h) {
            k[h] || (k[h] = []);
            k[h].push({
                h: l,
                one: !0
            })
        });
        return q
    };
    this.bind = function(h, l) {
        if (!l || !h) return q;
        ("string" == typeof h ? h.split(" ") : h).forEach(function(h) {
            k[h] || (k[h] = []);
            k[h].push({
                h: l,
                one: !1
            })
        });
        return q
    };
    this.unbind = function(h, l) {
        h || (k = {});
        var m = "string" == typeof h ? h.split(" ") : h;
        l ? m.forEach(function(h) {
            k[h] && (k[h] = k[h].filter(function(h) {
                return h.h !=
                    l
            }));
            k[h] && 0 == k[h].length && delete k[h]
        }) : m.forEach(function(h) {
            delete k[h]
        });
        return q
    };
    this.dispatch = function(h, l) {
        k[h] && (k[h].forEach(function(k) {
            k.h({
                type: h,
                content: l,
                target: q
            })
        }), k[h] = k[h].filter(function(h) {
            return !h.one
        }));
        return q
    }
};
(function() {
    function k() {
        function b(c) {
            return {
                x: c.x,
                y: c.y,
                size: c.size,
                degree: c.degree,
                inDegree: c.inDegree,
                outDegree: c.outDegree,
                displayX: c.displayX,
                displayY: c.displayY,
                degreeNotHidden: c.degreeNotHidden,
                manualDisplayX: c.manualDisplayX,
                manualDisplayY: c.manualDisplayY,
                displaySize: c.displaySize,
                label: c.label,
                id: c.id,
                color: c.color,
                fixed: c.fixed,
                active: c.active,
                hidden: c.hidden,
                forceLabel: c.forceLabel,
                attr: c.attr
            }
        }

        function u(c) {
            return {
                source: c.source.id,
                target: c.target.id,
                size: c.size,
                type: c.type,
                weight: c.weight,
                displaySize: c.displaySize,
                label: c.label,
                hidden: c.hidden,
                id: c.id,
                attr: c.attr,
                color: c.color
            }
        }

        function g() {
            c.nodesAttributes = {};
            c.edgesAttributes = {};
            c.nodes = [];
            c.nodesIndex = {};
            c.edges = [];
            c.edgesIndex = {};
            return c
        }
        sigma.classes.Cascade.call(this);
        sigma.classes.EventDispatcher.call(this);
        var c = this;
        this.p = {
            minNodeSize: 0,
            maxNodeSize: 0,
            minEdgeSize: 0,
            maxEdgeSize: 0,
            scalingMode: "inside",
            nodesPowRatio: 0.5,
            edgesPowRatio: 0,
            sideMargin: 0.1
        };
        this.borders = {};
        g();
        this.addNodeAttributes = function(a) {
            for (var b = 0; b < a.length; b++) c.nodesAttributes[a[b].id] =
                a[b];
            return c
        };
        this.getNodeAttributes = function() {
            return c.nodesAttributes
        };
        this.getNodeAttribute = function(c) {
            return this.getNodeAttributes()[c]
        };
        this.addEdgeAttributes = function(a) {
            for (var b = 0; b < a.length; b++) c.edgesAttributes[a[b].id] = a[b];
            return c
        };
        this.getEdgeAttributes = function() {
            return c.edgesAttributes
        };
        this.getEdgeAttribute = function(c) {
            return this.getEdgeAttributes()[c]
        };
        this.addNode = function(a, b) {
            if (c.nodesIndex[a]) throw Error('Node "' + a + '" already exists.');
            b = b || {};
            var f = {
                    x: 0,
                    y: 0,
                    size: 1,
                    degree: 0,
                    inDegree: 0,
                    outDegree: 0,
                    degreeNotHidden: 0,
                    fixed: !1,
                    active: !1,
                    hidden: !1,
                    forceLabel: !1,
                    label: a.toString(),
                    id: a.toString(),
                    attr: {}
                },
                d;
            for (d in b) switch (d) {
                case "id":
                    break;
                case "x":
                case "y":
                case "size":
                    f[d] = +b[d];
                    break;
                case "fixed":
                case "active":
                case "hidden":
                case "forceLabel":
                    f[d] = !!b[d];
                    break;
                case "color":
                case "label":
                    f[d] = b[d];
                    break;
                default:
                    f.attr[d] = b[d]
            }
            c.nodes.push(f);
            c.nodesIndex[a.toString()] = f;
            return c
        };
        this.addEdge = function(a, b, f, d) {
            if (c.edgesIndex[a]) throw Error('Edge "' + a + '" already exists.');
            if (!c.nodesIndex[b]) throw Error("Edge's source \"" + b + '" does not exist yet.');
            if (!c.nodesIndex[f]) throw Error("Edge's target \"" + f + '" does not exist yet.');
            d = d || {};
            b = {
                source: c.nodesIndex[b],
                target: c.nodesIndex[f],
                size: 1,
                weight: 1,
                displaySize: 0.5,
                label: a.toString(),
                id: a.toString(),
                hidden: !1,
                attr: {}
            };
            b.source.degree++;
            b.source.outDegree++;
            b.target.degree++;
            b.target.inDegree++;
            for (var g in d) switch (g) {
                case "id":
                case "source":
                case "target":
                    break;
                case "hidden":
                    b[g] = !!d[g];
                    break;
                case "size":
                case "weight":
                    b[g] = +d[g];
                    break;
                case "color":
                    b[g] = d[g].toString();
                    break;
                case "type":
                    b[g] = d[g].toString();
                    break;
                case "label":
                    b[g] = d[g];
                    break;
                default:
                    b.attr[g] = d[g]
            }
            c.edges.push(b);
            c.edgesIndex[a.toString()] = b;
            return c
        };
        this.dropNode = function(a) {
            ((a instanceof Array ? a : [a]) || []).forEach(function(a) {
                if (c.nodesIndex[a]) {
                    var f = null;
                    c.nodes.some(function(c, b) {
                        return c.id == a ? (f = b, !0) : !1
                    });
                    null != f && c.nodes.splice(f, 1);
                    delete c.nodesIndex[a];
                    c.edges = c.edges.filter(function(f) {
                        return f.source.id == a ? (delete c.edgesIndex[f.id], f.target.degree--,
                            f.target.inDegree--, !1) : f.target.id == a ? (delete c.edgesIndex[f.id], f.source.degree--, f.source.outDegree--, !1) : !0
                    })
                } else sigma.log('Node "' + a + '" does not exist.')
            });
            return c
        };
        this.dropEdge = function(a) {
            ((a instanceof Array ? a : [a]) || []).forEach(function(a) {
                if (c.edgesIndex[a]) {
                    c.edgesIndex[a].source.degree--;
                    c.edgesIndex[a].source.outDegree--;
                    c.edgesIndex[a].target.degree--;
                    c.edgesIndex[a].target.inDegree--;
                    var f = null;
                    c.edges.some(function(c, b) {
                        return c.id == a ? (f = b, !0) : !1
                    });
                    null != f && c.edges.splice(f, 1);
                    delete c.edgesIndex[a]
                } else sigma.log('Edge "' + a + '" does not exist.')
            });
            return c
        };
        this.iterEdges = function(a, b) {
            var f = b ? b.map(function(a) {
                    return c.edgesIndex[a]
                }) : c.edges,
                d = f.map(u);
            d.forEach(a);
            f.forEach(function(a, f) {
                var b = d[f],
                    g;
                for (g in b) switch (g) {
                    case "id":
                    case "displaySize":
                        break;
                    case "weight":
                    case "size":
                        a[g] = +b[g];
                        break;
                    case "source":
                    case "target":
                        a[g] = c.nodesIndex[g] || a[g];
                        break;
                    case "hidden":
                        a[g] = !!b[g];
                        break;
                    case "color":
                    case "label":
                    case "type":
                        a[g] = (b[g] || "").toString();
                        break;
                    default:
                        a.attr[g] =
                            b[g]
                }
            });
            return c
        };
        this.iterNodes = function(a, d) {
            var f = d ? d.map(function(a) {
                    return c.nodesIndex[a]
                }) : c.nodes,
                g = f.map(b);
            g.forEach(a);
            f.forEach(function(a, c) {
                var f = g[c],
                    b;
                for (b in f) switch (b) {
                    case "id":
                    case "attr":
                    case "degree":
                    case "inDegree":
                    case "outDegree":
                    case "displayX":
                    case "displayY":
                    case "degreeNotHidden":
                    case "manualDisplayX":
                        a[b] = f[b];
                        break;
                    case "manualDisplayY":
                        a[b] = f[b];
                        break;
                    case "displaySize":
                        break;
                    case "x":
                    case "y":
                    case "size":
                        a[b] = +f[b];
                        break;
                    case "fixed":
                    case "active":
                    case "hidden":
                    case "forceLabel":
                        a[b] = !!f[b];
                        break;
                    case "color":
                    case "label":
                        a[b] = (f[b] || "").toString();
                        break;
                    default:
                        a.attr[b] = f[b]
                }
            });
            return c
        };
        this.getEdges = function(a) {
            var b = ((a instanceof Array ? a : [a]) || []).map(function(a) {
                return u(c.edgesIndex[a])
            });
            return a instanceof Array ? b : b[0]
        };
        this.getNodes = function(a) {
            var d = ((a instanceof Array ? a : [a]) || []).map(function(a) {
                return b(c.nodesIndex[a])
            });
            return a instanceof Array ? d : d[0]
        };
        this.getNode = function(a) {
            return this.getNodes(a)
        };
        this.getNodeAttr = function(a, c) {
            for (var f = 0; f < a.attr.attributes.length; f++)
                if (nodeattr =
                    a.attr.attributes[f].attr, nodeval = a.attr.attributes[f].val, nodeattr == c) return nodeval
        };
        this.empty = g;
        var a = 0,
            h = 0,
            d = 1;
        this.rescale = function(b, g, f, u) {
            var k = 0,
                y = 0;
            f && c.nodes.forEach(function(a) {
                y = Math.max(a.size, y)
            });
            u && c.edges.forEach(function(a) {
                k = Math.max(a.size, k)
            });
            var y = y || 1,
                k = k || 1,
                w, B, l, x;
            f && c.nodes.forEach(function(a) {
                B = Math.max(a.x, B || a.x);
                w = Math.min(a.x, w || a.x);
                x = Math.max(a.y, x || a.y);
                l = Math.min(a.y, l || a.y)
            });
            var E = "outside" == c.p.scalingMode ? Math.max(b / Math.max(B - w, 1), g / Math.max(x - l, 1)) : Math.min(b /
                    Math.max(B - w, 1), g / Math.max(x - l, 1)),
                F = (c.p.maxNodeSize || y) / E + c.p.sideMargin;
            B += F;
            w -= F;
            x += F;
            l -= F;
            var E = "outside" == c.p.scalingMode ? Math.max(b / Math.max(B - w, 1), g / Math.max(x - l, 1)) : Math.min(b / Math.max(B - w, 1), g / Math.max(x - l, 1)),
                I, n;
            c.p.maxNodeSize || c.p.minNodeSize ? c.p.maxNodeSize == c.p.minNodeSize ? (I = 0, n = c.p.maxNodeSize) : (I = (c.p.maxNodeSize - c.p.minNodeSize) / y, n = c.p.minNodeSize) : (I = 1, n = 0);
            var p, r;
            c.p.maxEdgeSize || c.p.minEdgeSize ? (p = c.p.maxEdgeSize == c.p.minEdgeSize ? 0 : (c.p.maxEdgeSize - c.p.minEdgeSize) / k, r = c.p.minEdgeSize) :
                (p = 1, r = 0);
            f && c.nodes.forEach(function(c) {
                c.displaySize = c.size * I + n;
                if (!c.fixed)
                    if (0 <= c.manualDisplayX && 0 <= c.manualDisplayY) {
                        var f = (c.manualDisplayY - h) / d;
                        c.x = ((c.manualDisplayX - a) / d - b / 2) / E + (B + w) / 2;
                        c.y = (f - g / 2) / E + (x + l) / 2;
                        c.displayX = c.manualDisplayX;
                        c.displayY = c.manualDisplayY
                    } else c.displayX = (c.x - (B + w) / 2) * E + b / 2, c.displayY = (c.y - (x + l) / 2) * E + g / 2
            });
            u && c.edges.forEach(function(a) {
                a.displaySize = a.size * p + r
            });
            return c
        };
        this.translate = function(b, g, f, u, k) {
            a = b;
            h = g;
            d = f;
            var y = Math.pow(f, c.p.nodesPowRatio);
            u && c.nodes.forEach(function(a) {
                a.fixed ||
                    0 <= a.manualDisplayX && 0 <= a.manualDisplayY || (a.displayX = a.displayX * f + b, a.displayY = a.displayY * f + g);
                a.displaySize *= y
            });
            y = Math.pow(f, c.p.edgesPowRatio);
            k && c.edges.forEach(function(a) {
                a.displaySize *= y
            });
            return c
        };
        this.setBorders = function() {
            c.borders = {};
            c.nodes.forEach(function(a) {
                c.borders.minX = Math.min(void 0 == c.borders.minX ? a.displayX - a.displaySize : c.borders.minX, a.displayX - a.displaySize);
                c.borders.maxX = Math.max(void 0 == c.borders.maxX ? a.displayX + a.displaySize : c.borders.maxX, a.displayX + a.displaySize);
                c.borders.minY = Math.min(void 0 == c.borders.minY ? a.displayY - a.displaySize : c.borders.minY, a.displayY - a.displaySize);
                c.borders.maxY = Math.max(void 0 == c.borders.maxY ? a.displayY - a.displaySize : c.borders.maxY, a.displayY - a.displaySize)
            })
        };
        this.checkHover = function(a, b) {
            var f, d, g, y = [],
                w = [];
            c.nodes.forEach(function(c) {
                if (c.hidden) c.hover = !1;
                else {
                    f = Math.abs(c.displayX - a);
                    d = Math.abs(c.displayY - b);
                    g = c.displaySize;
                    var u = c.hover,
                        h = f < g && d < g && Math.sqrt(f * f + d * d) < g;
                    u && !h ? (c.hover = !1, w.push(c.id)) : h && !u && (c.hover = !0, y.push(c.id))
                }
            });
            y.length && c.dispatch("overnodes", y);
            w.length && c.dispatch("outnodes", w);
            return c
        }
    }

    function q(b, u) {
        function g() {
            var a;
            a = "<p>GLOBAL :</p>";
            for (var b in c.p.globalProbes) a += "<p>" + b + " : " + c.p.globalProbes[b]() + "</p>";
            a += "<br><p>LOCAL :</p>";
            for (b in c.p.localProbes) a += "<p>" + b + " : " + c.p.localProbes[b]() + "</p>";
            c.p.dom.innerHTML = a;
            return c
        }
        sigma.classes.Cascade.call(this);
        var c = this;
        this.instance = b;
        this.monitoring = !1;
        this.p = {
            fps: 40,
            dom: u,
            globalProbes: {
                "Time (ms)": sigma.chronos.getExecutionTime,
                Queue: sigma.chronos.getQueuedTasksCount,
                Tasks: sigma.chronos.getTasksCount,
                FPS: sigma.chronos.getFPS
            },
            localProbes: {
                "Nodes count": function() {
                    return c.instance.graph.nodes.length
                },
                "Edges count": function() {
                    return c.instance.graph.edges.length
                }
            }
        };
        this.activate = function() {
            c.monitoring || (c.monitoring = window.setInterval(g, 1E3 / c.p.fps));
            return c
        };
        this.desactivate = function() {
            c.monitoring && (window.clearInterval(c.monitoring), c.monitoring = null, c.p.dom.innerHTML = "");
            return c
        }
    }

    function h(b) {
        function u(c) {
            a.p.mouseEnabled && (g(a.mouseX, a.mouseY, a.ratio *
                (0 < (void 0 != c.wheelDelta && c.wheelDelta || void 0 != c.detail && -c.detail) ? a.p.zoomMultiply : 1 / a.p.zoomMultiply)), a.p.blockScroll) && (c.preventDefault ? c.preventDefault() : c.returnValue = !1)
        }

        function g(b, d, g) {
            a.isMouseDown || (window.clearInterval(a.interpolationID), E = void 0 != g, k = a.stageX, l = b, C = a.stageY, v = d, f = g || a.ratio, f = Math.min(Math.max(f, a.p.minRatio), a.p.maxRatio), x = a.p.directZooming ? 1 - (E ? a.p.zoomDelta : a.p.dragDelta) : 0, a.ratio == f && a.stageX == l && a.stageY == v) || (c(), a.interpolationID = window.setInterval(c, 50),
                a.dispatch("startinterpolate"))
        }

        function c() {
            x += E ? a.p.zoomDelta : a.p.dragDelta;
            x = Math.min(x, 1);
            var c = sigma.easing.quadratic.easeout(x),
                b = a.ratio;
            a.ratio = b * (1 - c) + f * c;
            E ? (a.stageX = l + (a.stageX - l) * a.ratio / b, a.stageY = v + (a.stageY - v) * a.ratio / b) : (a.stageX = k * (1 - c) + l * c, a.stageY = C * (1 - c) + v * c);
            a.dispatch("interpolate");
            1 <= x && (window.clearInterval(a.interpolationID), c = a.ratio, E ? (a.ratio = f, a.stageX = l + (a.stageX - l) * a.ratio / c, a.stageY = v + (a.stageY - v) * a.ratio / c) : (a.stageX = l, a.stageY = v), a.dispatch("stopinterpolate"))
        }
        sigma.classes.Cascade.call(this);
        sigma.classes.EventDispatcher.call(this);
        var a = this;
        this.p = {
            minRatio: 1,
            maxRatio: 32,
            marginRatio: 1,
            zoomDelta: 0.1,
            dragDelta: 0.3,
            zoomMultiply: 2,
            directZooming: !1,
            blockScroll: !0,
            inertia: 1.1,
            mouseEnabled: !0
        };
        var h = 0,
            d = 0,
            k = 0,
            C = 0,
            f = 1,
            l = 0,
            v = 0,
            y = 0,
            w = 0,
            B = 0,
            m = 0,
            x = 0,
            E = !1;
        this.stageY = this.stageX = 0;
        this.ratio = 1;
        this.mouseY = this.mouseX = 0;
        this.isControlKeyDown = this.isMouseDown = !1;
        b.addEventListener("DOMMouseScroll", u, !0);
        b.addEventListener("mousewheel", u, !0);
        b.addEventListener("mousemove", function(c) {
            a.mouseX = void 0 !=
                c.offsetX && c.offsetX || void 0 != c.layerX && c.layerX || void 0 != c.clientX && c.clientX;
            a.mouseY = void 0 != c.offsetY && c.offsetY || void 0 != c.layerY && c.layerY || void 0 != c.clientY && c.clientY;
            if (a.isMouseDown) {
                var b = a.mouseX - h + k,
                    f = a.mouseY - d + C;
                if (b != a.stageX || f != a.stageY) w = y, m = B, y = b, B = f, a.stageX = b, a.stageY = f, a.dispatch("drag")
            }
            a.dispatch("move");
            c.preventDefault ? c.preventDefault() : c.returnValue = !1
        }, !0);
        b.addEventListener("mousedown", function(c) {
            a.p.mouseEnabled && (a.isControlKeyDown ? a.dispatch("controlmousedown") :
                (a.isMouseDown = !0, a.dispatch("mousedown"), k = a.stageX, C = a.stageY, h = a.mouseX, d = a.mouseY, w = y = a.stageX, m = B = a.stageY, a.dispatch("startdrag"), c.preventDefault ? c.preventDefault() : c.returnValue = !1))
        }, !0);
        document.addEventListener("mouseup", function(c) {
            a.p.mouseEnabled && (a.isControlKeyDown && a.dispatch("controlmouseup"), a.isMouseDown && (a.isMouseDown = !1, a.dispatch("mouseup"), k == a.stageX && C == a.stageY || g(a.stageX + a.p.inertia * (a.stageX - w), a.stageY + a.p.inertia * (a.stageY - m)), c.preventDefault ? c.preventDefault() : c.returnValue = !1))
        }, !0);
        document.addEventListener("keydown", function(c) {
            17 == c.keyCode && (a.isControlKeyDown = !0)
        }, !0);
        document.addEventListener("keyup", function(c) {
            17 == c.keyCode && (a.isControlKeyDown = !1, a.dispatch("controlmouseup"))
        }, !0);
        this.checkBorders = function() {
            return a
        };
        this.interpolate = g
    }

    function l(b, u, g, c, a, h, d) {
        function k(a) {
            var b = c,
                d = "fixed" == f.p.labelSize ? f.p.defaultLabelSize : f.p.labelSizeRatio * a.displaySize;
            b.font = (f.p.hoverFontStyle || f.p.fontStyle || "") + " " + d + "px " + (f.p.hoverFont || f.p.font || "");
            b.fillStyle =
                "node" == f.p.labelHoverBGColor ? a.color || f.p.defaultNodeColor : f.p.defaultHoverLabelBGColor;
            b.beginPath();
            f.p.labelHoverShadow && (b.shadowOffsetX = 0, b.shadowOffsetY = 0, b.shadowBlur = 4, b.shadowColor = f.p.labelHoverShadowColor);
            sigma.tools.drawRoundRect(b, Math.round(a.displayX - d / 2 - 2), Math.round(a.displayY - d / 2 - 2), Math.round(b.measureText(a.label).width + 1.5 * (a.displaySize + f.p.borderSize) + d / 2 + 4), Math.round(d + 4), Math.round(d / 2 + 2), "left");
            b.closePath();
            b.fill();
            b.shadowOffsetX = 0;
            b.shadowOffsetY = 0;
            b.shadowBlur = 0;
            drawNode(b, a, f);
            b.fillStyle = "node" == f.p.labelHoverColor ? a.color || f.p.defaultNodeColor : f.p.defaultLabelHoverColor;
            b.fillText(a.label, Math.round(a.displayX + 1.5 * (a.displaySize + f.p.borderSize)), Math.round(a.displayY + d / 2.8));
            return f
        }

        function l(a) {
            if (isNaN(a.x) || isNaN(a.y)) throw Error("A node's coordinate is not a number (id: " + a.id + ")");
            return (a.degreeNotHidden || this.p.showOrphanNodes) && !a.hidden && a.displayX + a.displaySize > -G / 3 && a.displayX - a.displaySize < 4 * G / 3 && a.displayY + a.displaySize > -v / 3 && a.displayY -
                a.displaySize < 4 * v / 3
        }
        sigma.classes.Cascade.call(this);
        var f = this;
        this.p = {
            labelColor: "default",
            defaultLabelColor: "#000",
            labelHoverBGColor: "default",
            defaultHoverLabelBGColor: "#fff",
            labelHoverShadow: !0,
            labelHoverShadowColor: "#000",
            labelHoverColor: "default",
            defaultLabelHoverColor: "#000",
            labelActiveBGColor: "default",
            defaultActiveLabelBGColor: "#fff",
            labelActiveShadow: !0,
            labelActiveShadowColor: "#000",
            labelActiveColor: "default",
            defaultLabelActiveColor: "#000",
            labelSize: "fixed",
            defaultLabelSize: 12,
            labelSizeRatio: 2,
            labelThreshold: 6,
            font: "Arial",
            hoverFont: "",
            activeFont: "",
            fontStyle: "",
            hoverFontStyle: "",
            activeFontStyle: "",
            edgeColor: "original",
            defaultEdgeColor: "#aaa",
            defaultEdgeType: "line",
            defaultNodeColor: "#aaa",
            nodeHoverColor: "node",
            defaultNodeHoverColor: "#fff",
            nodeActiveColor: "node",
            defaultNodeActiveColor: "#fff",
            borderSize: 0,
            nodeBorderColor: "node",
            defaultNodeBorderColor: "#fff",
            edgesSpeed: 200,
            nodesSpeed: 200,
            labelsSpeed: 200,
            showEdgeLabels: !1,
            showOrphanNodes: !0,
            showSelfNodes: !0,
            edgeFontSize: 13,
            edgeLabelColor: "#fff",
            edgeLabelSizeRatio: 1,
            edgeLabelDecimals: 4
        };
        sigma.publicPrototype.getedgeLabelSizeRatio = function() {
            return f.p.edgeLabelSizeRatio
        };
        sigma.publicPrototype.getlabelSizeRatio = function() {
            return f.p.labelSizeRatio
        };
        sigma.publicPrototype.getedgeLabelDecimals = function() {
            return f.p.edgeLabelDecimals
        };
        var G = h,
            v = d;
        this.currentLabelIndex = this.currentNodeIndex = this.currentEdgeIndex = this.currentEdgesDrawnIndex = this.currentNodesDrawnIndex = 0;
        this.task_drawLabel = function() {
            for (var c = a.nodes.length, b = 0; b++ < f.p.labelsSpeed &&
                f.currentLabelIndex < c;)
                if (f.isOnScreen(a.nodes[f.currentLabelIndex])) {
                    var d = a.nodes[f.currentLabelIndex++],
                        h = g;
                    if (d.displaySize >= f.p.labelThreshold || d.forceLabel) {
                        var u = "fixed" == f.p.labelSize ? f.p.defaultLabelSize : f.p.labelSizeRatio * d.displaySize;
                        h.font = f.p.fontStyle + u + "px " + f.p.font;
                        h.fillStyle = "node" == f.p.labelColor ? d.color || f.p.defaultNodeColor : f.p.defaultLabelColor;
                        h.fillText(d.label, Math.round(d.displayX + 1.5 * (d.displaySize + f.p.borderSize)), Math.round(d.displayY + u / 2.8))
                    }
                } else f.currentLabelIndex++;
            return f.currentLabelIndex < c
        };
        this.task_drawEdge = function() {
			var edge_array = [];
            for (var c = a.edges.length, b, d, g = 0, b_curr, d_curr; g++ < f.p.edgesSpeed && f.currentEdgeIndex < c;){
                if (e = a.edges[f.currentEdgeIndex], b = e.source, d = e.target, e.hidden || !f.p.showSelfNodes && a.edges[f.currentEdgeIndex].source == a.edges[f.currentEdgeIndex].target || b.hidden || d.hidden || !f.isOnScreen(b) && !f.isOnScreen(d)) f.currentEdgeIndex++;
                else {
					b_curr = a.edges[f.currentEdgeIndex].source;
					d_curr = a.edges[f.currentEdgeIndex].target;
					var temp = b_curr.id + "-" + d_curr.id;
					if(edge_array[temp] == null)
						edge_array[temp] = 0;
					else
						edge_array[temp]++;
                    f.currentEdgesDrawnIndex++;
                    b = a.edges[f.currentEdgeIndex++];
                    d = b.source.displayX;
					
                    var h = b.source.displayY,
                        k = b.target.displayX,
                        l = b.target.displayY,
                        C = f.p.defaultEdgeColor,
                        n = d,
                        p = h,
                        r = k,
                        s = l,
                        L, G, v, m;
                    switch (f.p.edgeColor) {
                        case "original":
                            C = b.color || f.p.defaultEdgeColor;
                            break;
                        case "source":
                            C = b.source.color || f.p.defaultNodeColor;
                            break;
                        case "target":
                            C = b.target.color || f.p.defaultNodeColor;
                            break;
                        case "uniform":
                            C = f.p.defaultEdgeColor;
                            break;
                        default:
                            C = f.p.defaultEdgeColor
                    }
                    var t = u,
                        D = b.target.displaySize + f.p.borderSize;
                    switch (b.type || f.p.defaultEdgeType) {
                        case "curve":
                            var q, A;
                            n == r && p == s ? (h = n - 5 * D, k = p, q = n, A = p + 5 * D) : (h = (n + r) / 2 + (s - p) / 4, k = (p + s) / 2 + (n - r) / 4);
                            var z, J,
                                l = -(k - s) / (h - r);
                            t.fillStyle = t.strokeStyle = C;
                            t.lineWidth = b.displaySize / 3;
                            t.beginPath();
                            t.moveTo(n, p);
                            "directed" == graphDirection ? (z = r >= n && h >= r || r < n && h > r ? r + Math.abs(D / Math.sqrt(Math.pow(l, 2) + 1)) : r >= n && h < r || r < n && h <= r ? r - Math.abs(D / Math.sqrt(Math.pow(l, 2) + 1)) : r, J = s >= p && k >= s || s < p && k > s ? s + Math.abs(l * D / Math.sqrt(Math.pow(l, 2) + 1)) : s >= p && k < s || s < p && k <= s ? s - Math.abs(l * D / Math.sqrt(Math.pow(l, 2) + 1)) : s, v = z, m = J) : (v = r, m = s);
                            n == r && p == s ? t.bezierCurveTo(q, A, h - edge_array[temp] * 10, k + edge_array[temp] * 10, v + 0.01, m + 0.01) : t.quadraticCurveTo(h - edge_array[temp] * 10, k + edge_array[temp] * 10, v, m);
                            t.stroke();
                            if (n ==
                                r && p == s) v = n - 5 * Math.pow(D, 0.82) - b.displaySize / 7 - 9 * (f.p.edgeLabelSizeRatio * f.p.edgeFontSize / 13 - 1), m = p + 5 * Math.pow(D, 0.82) + b.displaySize / 7 + 9 * (f.p.edgeLabelSizeRatio * f.p.edgeFontSize / 13 - 1);
                            else {
                                L = Math.pow(0.5, 2) * n + 0.5 * h + Math.pow(0.5, 2) * v;
                                G = Math.pow(0.5, 2) * p + 0.5 * k + Math.pow(0.5, 2) * m;
                                var M = -(k - G) / (h - L);
                                v = L + Math.abs((5 + b.displaySize / 4) / Math.sqrt(Math.pow(M, 2) + 1));
                                m = G - Math.abs(M * (5 + b.displaySize / 4) / Math.sqrt(Math.pow(M, 2) + 1))
                            }
                            debug && (console.log("c.displaySize: " + b.displaySize), console.log("c.target.displaySize: " +
                                b.target.displaySize), console.log("(controlPointX,controlPointY): (" + h + "," + k + ")"), console.log("slopeMidControl: " + M), console.log("curveMidX: " + L), console.log("curveMidY: " + G), console.log("edgeLabelX: " + v), console.log("edgeLabelY: " + m));
                            if ("directed" == graphDirection) {
                                t.save();
                                var C = z - h,
                                    K = J - k;
                                debug && (console.log("nodeLabel source: " + b.source.label), console.log("nodeLabel target: " + b.target.label), console.log("graphDirection: " + graphDirection), console.log("c.target.displaySize: " + b.target.displaySize),
                                    console.log("c.target.size: " + b.target.size), console.log("radius: " + D), console.log("slope: " + l), console.log("(x1,y1): (" + n + "," + p + ")"), console.log("(x2,y2): (" + r + "," + s + ")"), console.log("(controlPointX,controlPointY): (" + h + "," + k + ")"), console.log("(xInt,yInt): (" + z + "," + J + ")"), console.log(""));
                                t.translate(z, J);
                                t.rotate(Math.atan2(K, C));
                                t.beginPath();
                                t.moveTo(0, -b.displaySize / 7);
                                t.lineTo(-b.displaySize, -b.displaySize / 1.5);
                                t.lineTo(-b.displaySize, b.displaySize / 1.5);
                                t.lineTo(0, b.displaySize / 7);
                                t.closePath();
                                t.fill();
                                t.restore()
                            }
                            break;
                        default:
                            v = b.displaySize / 3 + (r + n) / 2, m = -(b.displaySize / 3) + (s + p) / 2, t.strokeStyle = C, t.lineWidth = b.displaySize / 3, t.beginPath(), t.moveTo(d, h), t.lineTo(k, l), t.stroke()
                    }
                    f.p.showEdgeLabels && (t.save(), t.fillStyle = f.p.edgeLabelColor, t.font = f.p.edgeLabelSizeRatio * f.p.edgeFontSize + "px " + f.p.font, t.fillText(Number(b.label).toFixed(f.p.edgeLabelDecimals), v, m), t.restore())
                }
			}
            f.currentEdgeIndex == c && $("#visible_edges").length && $("#visible_edges").text(f.currentEdgesDrawnIndex + "/" + f.currentEdgeIndex +
                " (" + (100 * f.currentEdgesDrawnIndex / f.currentEdgeIndex).toFixed(0) + "%)");
            return f.currentEdgeIndex < c
        };
        drawNode = function(a, c, b) {
            a.fillStyle = c.color;
            a.beginPath();
            a.arc(c.displayX, c.displayY, c.displaySize, 0, 2 * Math.PI, !0);
            a.closePath();
            a.fill();
            0 < b.p.borderSize && (a.lineWidth = b.p.borderSize, a.strokeStyle = "node" == b.p.nodeBorderColor ? c.color || b.p.defaultNodeColor : b.p.defaultNodeBorderColor, a.stroke())
        };
        this.task_drawNode = function() {
            for (var c = a.nodes.length, d = 0; d++ < f.p.nodesSpeed && f.currentNodeIndex < c;)
                if (f.isOnScreen(a.nodes[f.currentNodeIndex])) {
                    var g =
                        a.nodes[f.currentNodeIndex++];
                    drawNode(b, g, f);
                    f.currentNodesDrawnIndex++;
                    g.hover && k(g)
                } else f.currentNodeIndex++;
            f.currentNodeIndex == c && $("#visible_nodes").length && $("#visible_nodes").text(f.currentNodesDrawnIndex + "/" + f.currentNodeIndex + " (" + (100 * f.currentNodesDrawnIndex / f.currentNodeIndex).toFixed(0) + "%)");
            return f.currentNodeIndex < c
        };
        this.drawActiveNode = function(a) {
            var b = c;
            if (!l(a)) return f;
            var d = "fixed" == f.p.labelSize ? f.p.defaultLabelSize : f.p.labelSizeRatio * a.displaySize;
            b.font = (f.p.activeFontStyle ||
                f.p.fontStyle || "") + " " + d + "px " + (f.p.activeFont || f.p.font || "");
            b.fillStyle = "node" == f.p.labelHoverBGColor ? a.color || f.p.defaultNodeColor : f.p.defaultActiveLabelBGColor;
            b.beginPath();
            f.p.labelActiveShadow && (b.shadowOffsetX = 0, b.shadowOffsetY = 0, b.shadowBlur = 4, b.shadowColor = f.p.labelActiveShadowColor);
            sigma.tools.drawRoundRect(b, Math.round(a.displayX - d / 2 - 2), Math.round(a.displayY - d / 2 - 2), Math.round(b.measureText(a.label).width + 1.5 * a.displaySize + d / 2 + 4), Math.round(d + 4), Math.round(d / 2 + 2), "left");
            b.closePath();
            b.fill();
            b.shadowOffsetX = 0;
            b.shadowOffsetY = 0;
            b.shadowBlur = 0;
            drawNode(b, a, f);
            b.fillStyle = "node" == f.p.labelActiveColor ? a.color || f.p.defaultNodeColor : f.p.defaultLabelActiveColor;
            b.fillText(a.label, Math.round(a.displayX + 1.5 * a.displaySize + f.p.borderSize), Math.round(a.displayY + d / 2.8));
            return f
        };
        this.drawHoverNode = k;
        this.isOnScreen = l;
        this.resize = function(a, b) {
            G = a;
            v = b;
            return f
        }
    }

    function m(b, u) {
        function g() {
            sigma.chronos.removeTask("node_" + d.id, 2).removeTask("edge_" + d.id, 2).removeTask("label_" + d.id, 2).stopTasks();
            return d
        }

        function c(a, b) {
            d.domElements[a] = document.createElement(b);
            d.domElements[a].style.position = "absolute";
            d.domElements[a].setAttribute("id", "sigma_" + a + "_" + d.id);
            d.domElements[a].setAttribute("class", "sigma_" + a + "_" + b);
            d.domElements[a].setAttribute("width", d.width + "px");
            d.domElements[a].setAttribute("height", d.height + "px");
            d.domRoot.appendChild(d.domElements[a]);
            return d
        }

        function a() {
            d.p.drawHoverNodes && (d.graph.checkHover(d.mousecaptor.mouseX, d.mousecaptor.mouseY), d.graph.nodes.forEach(function(a) {
                a.hover &&
                    !a.active && d.plotter.drawHoverNode(a)
            }));
            return d
        }

        function s() {
            d.p.drawActiveNodes && d.graph.nodes.forEach(function(a) {
                a.active && d.plotter.drawActiveNode(a)
            });
            return d
        }
        sigma.classes.Cascade.call(this);
        sigma.classes.EventDispatcher.call(this);
        var d = this;
        this.id = u.toString();
        this.p = {
            auto: !0,
            drawNodes: 2,
            drawEdges: 1,
            drawLabels: 2,
            lastNodes: 2,
            lastEdges: 0,
            lastLabels: 2,
            drawHoverNodes: !0,
            drawActiveNodes: !0
        };
        this.domRoot = b;
        this.width = this.domRoot.offsetWidth;
        this.height = this.domRoot.offsetHeight;
        this.graph =
            new k;
        this.domElements = {};
        c("edges", "canvas");
        c("nodes", "canvas");
        c("labels", "canvas");
        c("hover", "canvas");
        c("monitor", "div");
        c("mouse", "canvas");
        this.plotter = new l(this.domElements.nodes.getContext("2d"), this.domElements.edges.getContext("2d"), this.domElements.labels.getContext("2d"), this.domElements.hover.getContext("2d"), this.graph, this.width, this.height);
        this.monitor = new q(this, this.domElements.monitor);
        this.mousecaptor = new h(this.domElements.mouse, this.id);
        this.mousecaptor.bind("drag interpolate",
            function() {
                d.draw(d.p.auto ? 2 : d.p.drawNodes, d.p.auto ? 0 : d.p.drawEdges, d.p.auto ? 2 : d.p.drawLabels, !0)
            }).bind("stopdrag stopinterpolate", function() {
            d.draw(d.p.auto ? 2 : d.p.drawNodes, d.p.auto ? 1 : d.p.drawEdges, d.p.auto ? 2 : d.p.drawLabels, !0)
        }).bind("controlmousedown controlmouseup", function(a) {
            var b = d.graph.nodes.filter(function(a) {
                return !!a.hover
            }).map(function(a) {
                return a.id
            });
            d.dispatch("controlmousedown" == a.type ? "controldowngraph" : "controlupgraph");
            b.length && d.dispatch("controlmousedown" == a.type ? "controldownnodes" :
                "controlupnodes", b)
        }).bind("mousedown mouseup", function(a) {
            var b = d.graph.nodes.filter(function(a) {
                return !!a.hover
            }).map(function(a) {
                return a.id
            });
            d.dispatch("mousedown" == a.type ? "downgraph" : "upgraph");
            b.length && d.dispatch("mousedown" == a.type ? "downnodes" : "upnodes", b)
        }).bind("move", function() {
            a();
            s()
        });
        sigma.chronos.bind("startgenerators", function() {
            sigma.chronos.getGeneratorsIDs().some(function(a) {
                return !!a.match(RegExp("_ext_" + d.id + "$", ""))
            }) && d.draw(d.p.auto ? 2 : d.p.drawNodes, d.p.auto ? 0 : d.p.drawEdges,
                d.p.auto ? 2 : d.p.drawLabels)
        }).bind("stopgenerators", function() {
            d.draw()
        });
        for (var m = 0; m < A.length; m++) A[m](this);
        this.draw = function(a, b, c, h) {
            $("#searchnodes").length && $("#searchnodes").select2("val", "");
            if (h && sigma.chronos.getGeneratorsIDs().some(function(a) {
                    return !!a.match(RegExp("_ext_" + d.id + "$", ""))
                })) return d;
            a = void 0 == a ? d.p.drawNodes : a;
            b = void 0 == b ? d.p.drawEdges : b;
            c = void 0 == c ? d.p.drawLabels : c;
            h = {
                nodes: a,
                edges: b,
                labels: c
            };
            d.p.lastNodes = a;
            d.p.lastEdges = b;
            d.p.lastLabels = c;
            g();
            d.graph.rescale(d.width,
                d.height, 0 < a, 0 < b).setBorders();
            d.mousecaptor.checkBorders(d.graph.borders, d.width, d.height);
            d.graph.translate(d.mousecaptor.stageX, d.mousecaptor.stageY, d.mousecaptor.ratio, 0 < a, 0 < b);
            d.dispatch("graphscaled");
            for (var k in d.domElements) "canvas" == d.domElements[k].nodeName.toLowerCase() && (void 0 == h[k] || 0 <= h[k]) && d.domElements[k].getContext("2d").clearRect(0, 0, d.domElements[k].width, d.domElements[k].height);
            d.plotter.currentEdgeIndex = 0;
            d.plotter.currentNodeIndex = 0;
            d.plotter.currentLabelIndex = 0;
            d.plotter.currentNodesDrawnIndex =
                0;
            d.plotter.currentEdgesDrawnIndex = 0;
            k = null;
            h = !1;
            if (a) {
                if (!d.plotter.p.showOrphanNodes) {
                    for (var u = d.graph.nodes, l, s = 0; s < u.length; s++) l = u[s], l.degreeNotHidden = 0;
                    for (var u = d.graph.edges, m = l = 0, D = 0, s = 0; s < u.length; s++) l = u[s], m = l.source, D = l.target, l.hidden || m.hidden || D.hidden || (m.degreeNotHidden++, D.degreeNotHidden++)
                }
                if (1 < a)
                    for (; d.plotter.task_drawNode(););
                else sigma.chronos.addTask(d.plotter.task_drawNode, "node_" + d.id, !1), h = !0, k = "node_" + d.id;
            }
            if (c)
                if (1 < c)
                    for (; d.plotter.task_drawLabel(););
                else k ? sigma.chronos.queueTask(d.plotter.task_drawLabel,
                    "label_" + d.id, k) : sigma.chronos.addTask(d.plotter.task_drawLabel, "label_" + d.id, !1), h = !0, k = "label_" + d.id;
            if (b)
                if (1 < b)
                    for (; d.plotter.task_drawEdge(););
                else k ? sigma.chronos.queueTask(d.plotter.task_drawEdge, "edge_" + d.id, k) : sigma.chronos.addTask(d.plotter.task_drawEdge, "edge_" + d.id, !1), h = !0, k = "edge_" + d.id;
            
			d.dispatch("draw");
            d.refresh();
            h && sigma.chronos.runTasks();
            return d
        };
        this.resize = function(a, b) {
            var c = d.width,
                g = d.height;
            void 0 != a && void 0 != b ? (d.width = a, d.height = b) : (d.width = d.domRoot.offsetWidth, d.height =
                d.domRoot.offsetHeight);
            if (c != d.width || g != d.height) {
                for (var h in d.domElements) d.domElements[h].setAttribute("width", d.width + "px"), d.domElements[h].setAttribute("height", d.height + "px");
                d.plotter.resize(d.width, d.height);
                d.draw(d.p.lastNodes, d.p.lastEdges, d.p.lastLabels, !0)
            }
            return d
        };
        this.refresh = function() {
            d.domElements.hover.getContext("2d").clearRect(0, 0, d.domElements.hover.width, d.domElements.hover.height);
            a();
            s();
            return d
        };
        this.drawHover = a;
        this.drawActive = s;
        this.clearSchedule = g;
        window.addEventListener("resize",
            function() {
                d.resize()
            })
    }

    function z(b) {
        var h = this;
        sigma.classes.EventDispatcher.call(this);
        this._core = b;
        this.kill = function() {};
        this.getID = function() {
            return b.id
        };
        this.configProperties = function(g, c) {
            var a = b.config(g, c);
            return a == b ? h : a
        };
        this.drawingProperties = function(g, c) {
            var a = b.plotter.config(g, c);
            return a == b.plotter ? h : a
        };
        this.mouseProperties = function(g, c) {
            var a = b.mousecaptor.config(g, c);
            return a == b.mousecaptor ? h : a
        };
        this.graphProperties = function(g, c) {
            var a = b.graph.config(g, c);
            return a == b.graph ? h :
                a
        };
        this.getMouse = function() {
            return {
                mouseX: b.mousecaptor.mouseX,
                mouseY: b.mousecaptor.mouseY,
                down: b.mousecaptor.isMouseDown
            }
        };
        this.position = function(g, c, a) {
            if (0 == arguments.length) return {
                stageX: b.mousecaptor.stageX,
                stageY: b.mousecaptor.stageY,
                ratio: b.mousecaptor.ratio
            };
            b.mousecaptor.stageX = void 0 != g ? g : b.mousecaptor.stageX;
            b.mousecaptor.stageY = void 0 != c ? c : b.mousecaptor.stageY;
            b.mousecaptor.ratio = void 0 != a ? a : b.mousecaptor.ratio;
            return h
        };
        this.goTo = function(g, c, a) {
            b.mousecaptor.interpolate(g, c, a);
            return h
        };
        this.zoomTo = function(g, c, a) {
            a = Math.min(Math.max(b.mousecaptor.config("minRatio"), a), b.mousecaptor.config("maxRatio"));
            a == b.mousecaptor.ratio ? b.mousecaptor.interpolate(g - b.width / 2 + b.mousecaptor.stageX, c - b.height / 2 + b.mousecaptor.stageY) : b.mousecaptor.interpolate((a * g - b.mousecaptor.ratio * b.width / 2) / (a - b.mousecaptor.ratio), (a * c - b.mousecaptor.ratio * b.height / 2) / (a - b.mousecaptor.ratio), a);
            return h
        };
        this.resize = function(g, c) {
            b.resize(g, c);
            return h
        };
        this.draw = function(g, c, a, k) {
            b.draw(g, c, a, k);
            return h
        };
        this.refresh =
            function() {
                b.refresh();
                return h
            };
        this.addGenerator = function(g, c, a) {
            sigma.chronos.addGenerator(g + "_ext_" + b.id, c, a);
            return h
        };
        this.removeGenerator = function(g) {
            sigma.chronos.removeGenerator(g + "_ext_" + b.id);
            return h
        };
        this.addNodeAttributes = function(g) {
            b.graph.addNodeAttributes(g)
        };
        this.getNodeAttributes = function() {
            return b.graph.getNodeAttributes()
        };
        this.getNodeAttribute = function(g) {
            return b.graph.getNodeAttribute(g)
        };
        this.addEdgeAttributes = function(g) {
            b.graph.addEdgeAttributes(g)
        };
        this.getEdgeAttributes =
            function() {
                return b.graph.getEdgeAttributes()
            };
        this.getEdgeAttribute = function(g) {
            return b.graph.getEdgeAttribute(g)
        };
        this.addNode = function(g, c) {
            b.graph.addNode(g, c);
            return h
        };
        this.addEdge = function(g, c, a, k) {
            b.graph.addEdge(g, c, a, k);
            return h
        };
        this.dropNode = function(g) {
            b.graph.dropNode(g);
            return h
        };
        this.dropEdge = function(g) {
            b.graph.dropEdge(g);
            return h
        };
        this.pushGraph = function(g, c) {
            g.nodes && g.nodes.forEach(function(a) {
                !a.id || c && b.graph.nodesIndex[a.id] || h.addNode(a.id, a)
            });
            g.edges && g.edges.forEach(function(a) {
                !(validID =
                    a.source && a.target && a.id) || c && b.graph.edgesIndex[a.id] || h.addNode(a.id, a.source, a.target, a)
            });
            return h
        };
        this.emptyGraph = function() {
            b.graph.empty();
            return h
        };
        this.getNodesCount = function() {
            return b.graph.nodes.length
        };
        this.getEdgesCount = function() {
            return b.graph.edges.length
        };
        this.dynamicSort = function(b) {
            var c = 1;
            "-" === b[0] && (c = -1, b = b.substr(1, b.length - 1));
            return function(a, h) {
                return (a[b] < h[b] ? -1 : a[b] > h[b] ? 1 : 0) * c
            }
        };
        this.sortEdges = function(g) {
            b.graph.edges.sort(this.dynamicSort(g))
        };
        this.iterNodes = function(g,
            c) {
            b.graph.iterNodes(g, c);
            return h
        };
        this.iterEdges = function(g, c) {
            b.graph.iterEdges(g, c);
            return h
        };
        this.getNodes = function(g) {
            return b.graph.getNodes(g)
        };
        this.getNode = function(g) {
            return b.graph.getNode(g)
        };
        this.getNodeAttr = function(g, c) {
            return b.graph.getNodeAttr(g, c)
        };
        this.getEdges = function(g) {
            return b.graph.getEdges(g)
        };
        this.activateMonitoring = function() {
            return b.monitor.activate()
        };
        this.desactivateMonitoring = function() {
            return b.monitor.desactivate()
        };
        b.bind("controldownnodes controlupnodes downnodes upnodes downgraph upgraph",
            function(b) {
                h.dispatch(b.type, b.content)
            });
        b.graph.bind("overnodes outnodes", function(b) {
            h.dispatch(b.type, b.content)
        })
    }
    var A, K = 0;
    A = void 0;
    A = [];
    sigma.init = function(b) {
        b = new m(b, (++K).toString());
        sigma.instances[K] = new z(b);
        return sigma.instances[K]
    };
    sigma.addPlugin = function(b, h, g) {
        z.prototype[b] = h;
        A.push(g)
    };
    sigma.chronos = new function() {
        function b(a) {
            window.setTimeout(a, 0);
            return f
        }

        function h() {
            for (f.dispatch("frameinserted"); q && p.length && g(););
            q && p.length ? (F = (new Date).getTime(), w++, I = x - B, A = B - I,
                f.dispatch("insertframe"), b(h)) : a()
        }

        function g() {
            H %= p.length;
            if (!p[H].task()) {
                var a = p[H].taskName;
                r = r.filter(function(b) {
                    b.taskParent == a && p.push({
                        taskName: b.taskName,
                        task: b.task
                    });
                    return b.taskParent != a
                });
                f.dispatch("killed", p.splice(H--, 1)[0])
            }
            H++;
            x = (new Date).getTime() - F;
            return x <= A
        }

        function c() {
            q = !0;
            w = H = 0;
            z = F = (new Date).getTime();
            f.dispatch("start");
            f.dispatch("insertframe");
            b(h);
            return f
        }

        function a() {
            f.dispatch("stop");
            q = !1;
            return f
        }

        function k(a, b, d) {
            if ("function" != typeof a) throw Error('Task "' +
                b + '" is not a function');
            p.push({
                taskName: b,
                task: a
            });
            q = !!(q || d && c() || 1);
            return f
        }

        function d(a) {
            return a ? Object.keys(n).filter(function(a) {
                return !!n[a].on
            }).length : Object.keys(n).length
        }

        function l() {
            Object.keys(n).length ? (f.dispatch("startgenerators"), f.unbind("killed", m), b(function() {
                for (var a in n) n[a].on = !0, k(n[a].task, a, !1)
            }), f.bind("killed", m).runTasks()) : f.dispatch("stopgenerators");
            return f
        }

        function m(a) {
            void 0 != n[a.content.taskName] && (n[a.content.taskName].del || !n[a.content.taskName].condition() ?
                delete n[a.content.taskName] : n[a.content.taskName].on = !1, 0 == d(!0) && l())
        }
        sigma.classes.EventDispatcher.call(this);
        var f = this,
            q = !1,
            v = 80,
            y = 0,
            w = 0,
            B = 1E3 / v,
            A = B,
            x = 0,
            z = 0,
            F = 0,
            I = 0,
            n = {},
            p = [],
            r = [],
            H = 0;
        this.frequency = function(a) {
            return void 0 != a ? (v = Math.abs(1 * a), B = 1E3 / v, w = 0, f) : v
        };
        this.runTasks = c;
        this.stopTasks = a;
        this.insertFrame = b;
        this.addTask = k;
        this.queueTask = function(a, b, c) {
            if ("function" != typeof a) throw Error('Task "' + b + '" is not a function');
            if (!p.concat(r).some(function(a) {
                    return a.taskName == c
                })) throw Error('Parent task "' +
                c + '" of "' + b + '" is not attached.');
            r.push({
                taskParent: c,
                taskName: b,
                task: a
            });
            return f
        };
        this.removeTask = function(b, c) {
            if (void 0 == b) p = [], 1 == c ? r = [] : 2 == c && (p = r, r = []), a();
            else {
                var d = "string" == typeof b ? b : "";
                p = p.filter(function(a) {
                    return ("string" == typeof b ? a.taskName == b : a.task == b) ? (d = a.taskName, !1) : !0
                });
                0 < c && (r = r.filter(function(a) {
                    1 == c && a.taskParent == d && p.push(a);
                    return a.taskParent != d
                }))
            }
            q = !(p.length && (!a() || 1));
            return f
        };
        this.addGenerator = function(a, b, c) {
            if (void 0 != n[a]) return f;
            n[a] = {
                task: b,
                condition: c
            };
            0 == d(!0) && l();
            return f
        };
        this.removeGenerator = function(a) {
            n[a] && (n[a].on = !1, n[a].del = !0);
            return f
        };
        this.startGenerators = l;
        this.getGeneratorsIDs = function() {
            return Object.keys(n)
        };
        this.getFPS = function() {
            q && (y = Math.round(1E4 * (w / ((new Date).getTime() - z))) / 10);
            return y
        };
        this.getTasksCount = function() {
            return p.length
        };
        this.getQueuedTasksCount = function() {
            return r.length
        };
        this.getExecutionTime = function() {
            return F - z
        };
        return this
    };
    sigma.debugMode = 0;
    sigma.log = function() {
        if (1 == sigma.debugMode)
            for (var b in arguments) console.log(arguments[b]);
        else if (1 < sigma.debugMode)
            for (b in arguments) throw Error(arguments[b]);
        return sigma
    };
    sigma.easing = {
        linear: {},
        quadratic: {}
    };
    sigma.easing.linear.easenone = function(b) {
        return b
    };
    sigma.easing.quadratic.easein = function(b) {
        return b * b
    };
    sigma.easing.quadratic.easeout = function(b) {
        return -b * (b - 2)
    };
    sigma.easing.quadratic.easeinout = function(b) {
        return 1 > (b *= 2) ? 0.5 * b * b : -0.5 * (--b * (b - 2) - 1)
    };
    sigma.tools.drawRoundRect = function(b, h, g, c, a, k, d) {
        k = k ? k : 0;
        var l = d ? d : [],
            l = "string" == typeof l ? l.split(" ") : l;
        d = k && (0 <= l.indexOf("topleft") ||
            0 <= l.indexOf("top") || 0 <= l.indexOf("left"));
        var m = k && (0 <= l.indexOf("topright") || 0 <= l.indexOf("top") || 0 <= l.indexOf("right")),
            f = k && (0 <= l.indexOf("bottomleft") || 0 <= l.indexOf("bottom") || 0 <= l.indexOf("left")),
            l = k && (0 <= l.indexOf("bottomright") || 0 <= l.indexOf("bottom") || 0 <= l.indexOf("right"));
        b.moveTo(h, g + k);
        d ? b.arcTo(h, g, h + k, g, k) : b.lineTo(h, g);
        m ? (b.lineTo(h + c - k, g), b.arcTo(h + c, g, h + c, g + k, k)) : b.lineTo(h + c, g);
        l ? (b.lineTo(h + c, g + a - k), b.arcTo(h + c, g + a, h + c - k, g + a, k)) : b.lineTo(h + c, g + a);
        f ? (b.lineTo(h + k, g + a), b.arcTo(h,
            g + a, h, g + a - k, k)) : b.lineTo(h, g + a);
        b.lineTo(h, g + k)
    };
    sigma.tools.getRGB = function(b, h) {
        b = b.toString();
        var g = {
            r: 0,
            g: 0,
            b: 0
        };
        if (3 <= b.length && "#" == b.charAt(0)) {
            var c = b.length - 1;
            6 == c ? g = {
                r: parseInt(b.charAt(1) + b.charAt(2), 16),
                g: parseInt(b.charAt(3) + b.charAt(4), 16),
                b: parseInt(b.charAt(5) + b.charAt(5), 16)
            } : 3 == c && (g = {
                r: parseInt(b.charAt(1) + b.charAt(1), 16),
                g: parseInt(b.charAt(2) + b.charAt(2), 16),
                b: parseInt(b.charAt(3) + b.charAt(3), 16)
            })
        }
        h && (g = [g.r, g.g, g.b]);
        return g
    };
    sigma.tools.rgbToHex = function(b, h, g) {
        return sigma.tools.toHex(b) +
            sigma.tools.toHex(h) + sigma.tools.toHex(g)
    };
    sigma.tools.toHex = function(b) {
        b = parseInt(b, 10);
        if (isNaN(b)) return "00";
        b = Math.max(0, Math.min(b, 255));
        return "0123456789ABCDEF".charAt((b - b % 16) / 16) + "0123456789ABCDEF".charAt(b % 16)
    };
    sigma.publicPrototype = z.prototype
})();