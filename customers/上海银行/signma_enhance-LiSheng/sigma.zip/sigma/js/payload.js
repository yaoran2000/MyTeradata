//PURPOSE: create a zip file based on a list of files

//HOW TO USE:
//1. In your HTML, include javascript files:
//jszip_min.js
//payload.js
//2. In your HTML, add a link to the zip file:
//<a href="javascript:createZip('sigma_123')" id="download_zip">download zip</a>

//REQUIREMENTS:
//The HTML page must contain an <a href...> with id="download_zip"

//INPUTS:
//id : unique id for the viz, e.g. sigma_1380756381800_0068_1

//OUTPUT:
//zip file will be created and sent back to browser

//check if file exists by looking at http object
//local files (e.g. off hard drive):
//OK:     readyState=4, status=0, response.length>0
//NOT OK: readyState=4, status=0, response.length=0

//remote files (e.g. from web server:
//OK:     readyState=4, status=200(OK) or 304(cache hit)
//NOT OK: readyState=4, status=404(file not found)

function httpOK(http) {
	// OK: local file
	if (http.readyState == 4 && http.status == 0 && http.response.length > 0) return true;

	// NOT OK: local file
	if (http.readyState == 4 && http.status == 0 && http.response.length == 0) return false;

	// OK: remote file
	if (http.readyState == 4 && (http.status == 200 || http.status == 304)) return true;

	// NOT OK: remote file
	if (http.readyState == 4 && http.status == 404) return false;

	// if no other condition is caught, rely on 404
	return http.status!=404;
}

//check if a file exists at a specified URL
function urlExists(url) {
	try {
		var http = new XMLHttpRequest();
		http.open('HEAD', url, false);
		http.overrideMimeType("text/plain");
		http.send();
	} catch (error) {
		return false;
	}
	return httpOK(http);
}

//Return last part of URL, e.g. if url is:
//https://153.64.249.87/chrysalis/mr/graphgen/sigma/sigma.html?id=sigma_1382668060258_0018_1
//returns: sigma.html?id=sigma_1382668060258_0018_1
function getPagename() {
	var pathArray = window.location.href.split('/');
	var pagename = pathArray[pathArray.length-1];
	return pagename;
}

function getManifestName(id) {
	return (id + '.payload.json');
}

function createZip(id) {
	// Get payload JSON that contains manifest (list of files to be zipped)
	// The id tells us which json file to get.
	var request = new XMLHttpRequest();
	var urls;
	try {
		request.open('GET', getManifestName(id), false);
		request.overrideMimeType("application/json");
		request.send();
		urls = JSON.parse(request.responseText).files;
	}
	catch (error) {
		urls = new Array();
		alert("An error occurred. Unable to download zip file.");
	}
	var zip = new JSZip();

	// Add redirect page to ZIP.
	var redirectHTML = ''
		+	'<!DOCTYPE HTML>\n'
		+   '<html lang="en-US">\n'
		+   '   <head>\n'
		+   '      <meta charset="UTF-8">\n'
		+   '      <meta http-equiv="refresh" content="1;url=' + getPagename() + '">\n'
		+   '      <script type="text/javascript">\n'
		+   '         window.location.href = "' + getPagename() + '"\n'
		+   '      </script>\n'
		+   '      <title>Page Redirection</title>\n'
		+   '   </head>\n'
		+   '   <body>\n'
		+   '      If you are not redirected automatically, <a href="' + getPagename() + '">click here</a>\n'
		+   '   </body>\n'
		+   '</html>\n'
		;
	zip.file("index.html", redirectHTML);

	// Each URL get is async. But, we need to know when the last one is done.
	// Thus, we call all the gets in a nested, stack like fashion.
	function run() {
		var nbResponses = 0;
		for (var i = 0; i < urls.length; i++) {
			processUrl(urls[i], function () {  
				nbResponses++;
				if (nbResponses == urls.length) {
					done();  
				}  
			});  
		}  
	} 

	function done() {	 
		// Generate zip file as a browser blob
		var blobLink = document.getElementById('download_zip'); // div id of href for download zip link
		try {
			blobLink.download = id + ".zip"; // name of resulting zip file, if browser supports it
			blobLink.href = window.URL.createObjectURL(zip.generate({type:"blob"}));
			blobLink.click();
		} catch(e) {
			blobLink.innerHTML += " (not supported on this browser)";
		}
	}

	// Get a file to be part of the final zip file.
	function processUrl (url, callback) {
		var request = new XMLHttpRequest();
		request.open('GET', url);
		request.responseType = 'arraybuffer';

		request.onreadystatechange = function(e) {
			if (this.readyState == 4) {
				if (httpOK(this)) zip.file(url, this.response);
				else alert("An error occurred. Unable to find file:\n" + url + "\nZip file will be incomplete.");
				if (callback) callback();
			}
		};

		request.send();  
	}

	run();  
}
